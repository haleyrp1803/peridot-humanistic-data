import { getRowTimelineCapability, getRowTemporalSearchValues, getRowTemporalYears, getRowTemporalDisplayLabels } from './timelinePlaybackHelpers.js';
import { getPeridotRowEntityParticipantEntries, getPeridotRowEntityParticipants, getPeridotRowEntityRelationshipLabels, getPeridotRowEntityRelationships, rowHasPeridotEntityRelationship } from './peridotEntityNetwork.js';
import { buildPeridotRecordStructure } from './peridotRecordStructure.js';
import { buildPeridotCanonicalSearchEvidenceBySourceRow } from './peridotEntityEvidence.js';

/*
 * Search-result helpers for Peridot's Advanced Search workspace.
 *
 * Phase 2 scope:
 * - derive lightweight result-card records from the already filtered active rows;
 * - explain which applied search terms and capability filters matched a row;
 * - expose capability predicates for App.jsx's global Search & Filter pipeline;
 * - derive result facets/counts for Search refinement without introducing saved-search persistence.
 *
 * Phase 3 scope:
 * - add a small structured-criteria evaluator for App.jsx's global active-row
 *   filtering pipeline;
 * - support simple non-nested Boolean operators displayed to users as
 *   Start with, AND, OR, and EXCLUDING;
 * - keep all helper functions pure and UI-agnostic so the Search workspace can
 *   remain a presentation/control surface rather than a second data pipeline.
 *
 * Phase 4 scope:
 * - support a dataset-wide Browse index by allowing structured criteria to match
 *   evidence/custom field labels, not only evidence field values.
 */
const FIELD_LABELS = {
  date: 'Date',
  displayDate: 'Display date',
  sourcePerson: 'Source entity',
  source: 'Source entity',
  targetPerson: 'Target entity',
  target: 'Target entity',
  sourcePlaceLabel: 'Source place',
  targetPlaceLabel: 'Target place',
  sourcePlace: 'Source place',
  targetPlace: 'Target place',
  sourceLoc: 'Source place',
  targetLoc: 'Target place',
  relationshipType: 'Relationship',
  relationship: 'Relationship',
  archive: 'Archive',
  archivalCollection: 'Archival collection',
  archivalPage: 'Archival page',
  pdfPage: 'PDF page',
  cipher: 'Cipher',
  topic: 'Topic',
  language: 'Language',
  transcription: 'Transcription',
  translation: 'Translation',
  sourceTitle: 'Source title',
  targetTitle: 'Target title',
  title: 'Title',
  citation: 'Citation',
  notes: 'Notes',
  links: 'Links',
};

const TITLE_FIELDS = ['title', 'recordTitle', 'Title', 'Record_Title', 'Letter_Title', 'label'];
const DATE_FIELDS = ['displayDate', 'date', 'Date', 'Date*', 'dateDisplay', 'dateLabel'];
const SOURCE_PERSON_FIELDS = ['sourcePerson', 'source', 'Source', 'Source_Person', 'Source_Entity', 'sender', 'Sender'];
const TARGET_PERSON_FIELDS = ['targetPerson', 'target', 'Target', 'Target_Person', 'Target_Entity', 'recipient', 'Recipient'];
const SOURCE_PLACE_FIELDS = ['sourcePlaceLabel', 'sourcePlace', 'sourceLoc', 'Source_Loc', 'Source_Place', 'sourceLocation'];
const TARGET_PLACE_FIELDS = ['targetPlaceLabel', 'targetPlace', 'targetLoc', 'Target_Inferred_Loc', 'Target_Loc', 'Target_Place', 'targetLocation'];
const COORDINATE_FIELDS = ['sourceLat', 'sourceLon', 'targetLat', 'targetLon', 'lat', 'lon', 'latitude', 'longitude'];
const EVIDENCE_FIELDS = [
  'archivalCollection',
  'archivalPage',
  'pdfPage',
  'relationship',
  'relationshipType',
  'cipher',
  'topic',
  'language',
  'transcription',
  'translation',
  'notes',
  'citation',
  'sourceTitle',
  'targetTitle',
];

const CORE_FIELDS = new Set([
  'id',
  'recordId',
  ...TITLE_FIELDS,
  ...DATE_FIELDS,
  ...SOURCE_PERSON_FIELDS,
  ...TARGET_PERSON_FIELDS,
  ...SOURCE_PLACE_FIELDS,
  ...TARGET_PLACE_FIELDS,
  ...COORDINATE_FIELDS,
  'sourcePlaceId',
  'targetPlaceId',
  'mappable',
  'personKey',
  'dateStart',
  'dateEnd',
  'dateDisplay',
  'pointLoc',
  'pointCoordinates',
  'pointLat',
  'pointLon',
  'pointPlaceId',
  'pointRecord',
  'sourcePoliticalHint',
  'targetPoliticalHint',
]);

/*
 * These fields are implementation payloads rather than researcher-facing
 * evidence. They must not appear as Browse/Refine evidence fields, and nested
 * objects must not be stringified into misleading “[object Object]” entries.
 */
const NON_EVIDENCE_FIELD_KEYS = new Set([
  ...CORE_FIELDS,
  'peridotCapabilities',
  'capabilities',
  'capabilityFlags',
  'customInspectorFields',
  'peridotCanonicalEvidenceFields',
  'ignoredUploadedColumns',
  'originalUploadedRow',
  'originalTemplateRow',
]);


function normalizeLinkText(value) {
  const normalized = asText(value).toLowerCase();
  // The bundled legacy tables use 0 as an empty-cell sentinel in a handful
  // of source-entity cells. Treat it as blank for record-link validation only.
  return normalized === '0' ? '' : normalized;
}

function getRecordId(row) {
  return asText(row?.recordId || row?.sourceRecordId || row?.sourceRecordKey);
}

function getSourcePerson(row) {
  return firstText(row, SOURCE_PERSON_FIELDS);
}

function getTargetPerson(row) {
  return firstText(row, TARGET_PERSON_FIELDS);
}

function getSourcePlace(row) {
  return firstText(row, SOURCE_PLACE_FIELDS);
}

function getMappedPlaceEntries(row) {
  return buildPeridotRecordStructure(row || {}).places || [];
}

function getMappedPlaceValues(row) {
  return getMappedPlaceEntries(row)
    .map((entry) => asText(entry?.value))
    .filter(Boolean);
}

function hasMappedPlaceCoordinates(row) {
  return getMappedPlaceEntries(row).some((entry) => (
    Number.isFinite(entry?.latitude)
    && Number.isFinite(entry?.longitude)
  ));
}

function getLegacyRecordSignature(row) {
  return [
    normalizeLinkText(firstText(row, DATE_FIELDS)),
    normalizeLinkText(getSourcePerson(row)),
    normalizeLinkText(getTargetPerson(row)),
    normalizeLinkText(getSourcePlace(row)),
  ].join('\u0000');
}

function buildUniqueLinkedRecordIndex(linkedRows) {
  const groups = new Map();
  (Array.isArray(linkedRows) ? linkedRows : []).forEach((row) => {
    const recordId = getRecordId(row);
    if (!recordId) return;
    const current = groups.get(recordId) || [];
    current.push(row);
    groups.set(recordId, current);
  });

  const unique = new Map();
  groups.forEach((rows, recordId) => {
    if (rows.length === 1) unique.set(recordId, rows[0]);
  });
  return unique;
}

function buildValidatedParallelLinkedRecordIndex(geographyRows, linkedRows) {
  const linkedByIndex = new Map();
  const geography = Array.isArray(geographyRows) ? geographyRows : [];
  const linked = Array.isArray(linkedRows) ? linkedRows : [];

  if (!geography.length || geography.length !== linked.length) return linkedByIndex;

  geography.forEach((geographyRow, index) => {
    const linkedRow = linked[index];
    if (!linkedRow) return;
    const geographySignature = getLegacyRecordSignature(geographyRow);
    const linkedSignature = getLegacyRecordSignature(linkedRow);

    /*
     * This compatibility route is intentionally strict: it is available only
     * to the bundled parallel legacy sample tables and only when the record at
     * the same ordinal position agrees on date, source, target, and source
     * place. It never performs a loose person/date/place lookup.
     */
    if (geographySignature && geographySignature === linkedSignature) {
      linkedByIndex.set(index, linkedRow);
    }
  });

  return linkedByIndex;
}

function getLinkedResearchMetadata(linkedRow) {
  if (!linkedRow) return {};

  const metadata = {};
  Object.entries(linkedRow).forEach(([key, value]) => {
    if (
      key === 'id'
      || key === 'recordId'
      || key === 'sourceRecordId'
      || key === 'sourceRecordKey'
      || key === 'source'
      || key === 'target'
      || key === 'sourceLoc'
      || key === 'targetLoc'
      || key === 'date'
      || key === 'personKey'
      || key === 'peridotCapabilities'
      || key === 'capabilities'
      || key === 'capabilityFlags'
      || key === 'ignoredUploadedColumns'
      || key === 'originalUploadedRow'
      || key === 'originalTemplateRow'
      || key === 'customInspectorFields'
      || !isSearchableScalar(value)
      || !asText(value)
    ) {
      return;
    }
    metadata[key] = value;
  });

  const customInspectorFields = Array.isArray(linkedRow.customInspectorFields)
    ? linkedRow.customInspectorFields.map((field) => ({ ...field }))
    : [];

  if (customInspectorFields.length) metadata.customInspectorFields = customInspectorFields;
  return metadata;
}

/*
 * Create the one record shape evaluated by Search. Map and graph consumers
 * retain the geographic row fields they already require; researcher-facing
 * metadata is copied from an exactly linked record where that relationship is
 * known. This helper never guesses a link from an arbitrary matching person,
 * date, or place value.
 */
export function buildPeridotSearchRecords(geographyRows = [], linkedRows = [], options = {}) {
  const geography = Array.isArray(geographyRows) ? geographyRows : [];
  const linkedByRecordId = buildUniqueLinkedRecordIndex(linkedRows);
  const linkedByValidatedIndex = options.allowValidatedParallelRows
    ? buildValidatedParallelLinkedRecordIndex(geography, linkedRows)
    : new Map();
  const canonicalEvidenceBySourceRow = options.canonicalEvidenceBySourceRow instanceof Map
    ? options.canonicalEvidenceBySourceRow
    : buildPeridotCanonicalSearchEvidenceBySourceRow(options.canonicalDataset || null);
  const canonicalEvidenceAuthoritative = Boolean(options.canonicalEvidenceAuthoritative);

  return geography.map((geographyRow, index) => {
    const recordId = getRecordId(geographyRow);
    const linkedRow = (recordId && linkedByRecordId.get(recordId)) || linkedByValidatedIndex.get(index) || null;
    const metadata = getLinkedResearchMetadata(linkedRow);
    const sourceRowNumber = Number(geographyRow?.generalizedObservation?.rowIndex) + 2;
    const canonicalEvidence = Number.isFinite(sourceRowNumber)
      ? canonicalEvidenceBySourceRow.get(sourceRowNumber) || []
      : [];

    return {
      ...geographyRow,
      ...metadata,
      ...(canonicalEvidenceAuthoritative || canonicalEvidence.length
        ? { peridotCanonicalEvidenceFields: canonicalEvidence }
        : {}),
    };
  });
}

export const CAPABILITY_FILTER_OPTIONS = Object.freeze([
  {
    id: 'inspector-ready',
    label: 'Inspector-ready',
    shortLabel: 'Inspector',
    description: 'Rows with enough content to open as evidence records.',
  },
  {
    id: 'map-ready',
    label: 'Map-relevant',
    shortLabel: 'Map',
    description: 'Rows with place names or coordinate evidence.',
  },
  {
    id: 'route-ready',
    label: 'Route-ready',
    shortLabel: 'Route',
    description: 'Rows with source/target route evidence.',
  },
  {
    id: 'network-ready',
    label: 'Network-ready',
    shortLabel: 'Network',
    description: 'Rows with at least one mapped entity relationship.',
  },
  {
    id: 'timeline-ready',
    label: 'Timeline-ready',
    shortLabel: 'Timeline',
    description: 'Rows with at least one date or period that can be positioned on the timeline.',
  },
  {
    id: 'evidence-ready',
    label: 'Evidence-rich',
    shortLabel: 'Evidence',
    description: 'Rows with researcher-mapped Evidence assertions.',
  },
  {
    id: 'missing-date',
    label: 'Missing time',
    shortLabel: 'No time',
    description: 'Rows without mapped temporal evidence.',
  },
  {
    id: 'missing-coordinates',
    label: 'Missing coordinates',
    shortLabel: 'No coordinates',
    description: 'Rows without detected route or point coordinates.',
  },
]);

function asText(value) {
  return String(value ?? '').trim();
}

function firstText(row, fields) {
  for (const field of fields) {
    const value = asText(row?.[field]);
    if (value) return value;
  }
  return '';
}

function includesNeedle(value, needle) {
  const cleanNeedle = asText(needle).toLowerCase();
  if (!cleanNeedle) return false;
  return asText(value).toLowerCase().includes(cleanNeedle);
}

function hasFiniteCoordinate(value) {
  if (value === null || value === undefined || value === '') return false;
  const numeric = Number(value);
  return Number.isFinite(numeric) && numeric !== 0;
}

function hasAnyCoordinate(row) {
  if (row?.mappable) return true;
  return COORDINATE_FIELDS.some((field) => hasFiniteCoordinate(row?.[field]));
}

function isSearchableScalar(value) {
  return (
    typeof value === 'string'
    || typeof value === 'number'
    || typeof value === 'boolean'
  );
}

function getFieldLabel(key) {
  return FIELD_LABELS[key] || String(key || '').replace(/_/g, ' ');
}

function collectCustomInspectorFieldEntries(row) {
  const fields = Array.isArray(row?.customInspectorFields) ? row.customInspectorFields : [];
  return fields
    .filter((field) => isSearchableScalar(field?.value) && asText(field?.value))
    .map((field) => ({
      key: asText(field?.key || field?.sourceColumn || field?.label),
      label: asText(field?.label || field?.sourceColumn || field?.key) || 'Custom metadata',
      value: asText(field?.value),
    }));
}

function collectCanonicalEvidenceFieldEntries(row) {
  const fields = Array.isArray(row?.peridotCanonicalEvidenceFields)
    ? row.peridotCanonicalEvidenceFields
    : null;
  if (!fields) return null;

  return fields
    .filter((field) => isSearchableScalar(field?.value) && asText(field?.value))
    .map((field) => ({
      key: asText(field?.key || field?.sourceColumn || field?.label),
      label: asText(field?.label || field?.sourceColumn || field?.key) || 'Evidence',
      value: asText(field?.value),
      subjectId: asText(field?.subjectId),
      subjectType: asText(field?.subjectType),
      subjectLabel: asText(field?.subjectLabel),
      assertionId: asText(field?.assertionId),
      sourceColumn: asText(field?.sourceColumn),
    }));
}

/*
 * Search deliberately operates on researcher-facing scalar values. Internal
 * geometry, timeline, capability, and original-row payloads are excluded so
 * technical identifiers cannot create misleading keyword or metadata matches.
 */
function collectSearchableFields(row) {
  const entries = [];

  Object.entries(row || {}).forEach(([key, value]) => {
    if (
      NON_EVIDENCE_FIELD_KEYS.has(key)
      || value === null
      || value === undefined
      || !isSearchableScalar(value)
      || !asText(value)
    ) {
      return;
    }
    entries.push({ key, label: getFieldLabel(key), value: asText(value) });
  });

  const canonicalEvidence = collectCanonicalEvidenceFieldEntries(row);
  if (canonicalEvidence) {
    canonicalEvidence.forEach((entry) => entries.push(entry));
  } else {
    collectCustomInspectorFieldEntries(row).forEach((entry) => entries.push(entry));
  }

  const deduped = new Map();
  entries.forEach((entry) => {
    const dedupeKey = `${entry.key}\u0000${entry.label}\u0000${entry.value}`;
    if (!deduped.has(dedupeKey)) deduped.set(dedupeKey, entry);
  });

  return Array.from(deduped.values());
}

export function rowMatchesSearchText(row, query) {
  const cleanQuery = asText(query);
  if (!cleanQuery) return true;

  return collectSearchableFields(row).some((field) => (
    includesNeedle(field.value, cleanQuery) || includesNeedle(field.label, cleanQuery)
  ));
}

/*
 * A single shared Evidence-field inventory keeps Browse, Refine facets, and
 * structured “Evidence field present” criteria aligned. Canonical mapped
 * Evidence assertions are authoritative when attached to the Search record;
 * legacy scalar metadata remains only as a compatibility fallback.
 */
export function getSearchableEvidenceFieldEntries(row) {
  const canonicalEvidence = collectCanonicalEvidenceFieldEntries(row);
  if (canonicalEvidence) return canonicalEvidence;

  const entries = [];

  Object.entries(row || {}).forEach(([key, value]) => {
    if (
      NON_EVIDENCE_FIELD_KEYS.has(key)
      || value === null
      || value === undefined
      || !isSearchableScalar(value)
      || !asText(value)
    ) {
      return;
    }
    entries.push({ key, label: getFieldLabel(key), value: asText(value) });
  });

  collectCustomInspectorFieldEntries(row).forEach((entry) => entries.push(entry));

  const fieldsByIdentity = new Map();
  entries.forEach((entry) => {
    const identity = `${entry.key}\u0000${entry.label}`;
    if (!fieldsByIdentity.has(identity)) fieldsByIdentity.set(identity, entry);
  });

  return Array.from(fieldsByIdentity.values());
}

function hasAnyEvidenceField(row) {
  return getSearchableEvidenceFieldEntries(row).length > 0;
}

function hasAnySearchableContent(row) {
  return collectSearchableFields(row).length > 0;
}

function findFirstFieldMatch(row, query, preferredKeys = []) {
  const cleanQuery = asText(query);
  if (!cleanQuery) return null;
  const fields = collectSearchableFields(row);
  const preferred = fields.filter((field) => preferredKeys.includes(field.key));
  const remaining = fields.filter((field) => !preferredKeys.includes(field.key));
  return [...preferred, ...remaining].find((field) => includesNeedle(field.value, cleanQuery)) || null;
}

function compactRouteLabel(source, target) {
  const cleanSource = asText(source) || 'Unknown source';
  const cleanTarget = asText(target) || 'Unknown target';
  return `${cleanSource} → ${cleanTarget}`;
}

function addFacetCount(map, rawValue) {
  const value = asText(rawValue);
  if (!value) return;
  map.set(value, (map.get(value) || 0) + 1);
}

function facetItemsFromMap(map, limit = Number.POSITIVE_INFINITY) {
  const safeLimit = Number.isFinite(limit) ? Math.max(1, limit) : Number.POSITIVE_INFINITY;
  return Array.from(map.entries())
    .map(([value, count]) => ({ value, count }))
    .sort((a, b) => {
      if (b.count !== a.count) return b.count - a.count;
      return a.value.localeCompare(b.value);
    })
    .slice(0, safeLimit);
}

function buildResultTitle(row, index) {
  const explicitTitle = firstText(row, TITLE_FIELDS);
  if (explicitTitle) return explicitTitle;
  const relationshipLabels = getPeridotRowEntityRelationshipLabels(row);
  if (relationshipLabels.length) return relationshipLabels.join(' · ');
  const participants = getPeridotRowEntityParticipants(row);
  if (participants.length) return participants.join(' · ');
  const sourcePlace = firstText(row, SOURCE_PLACE_FIELDS);
  const targetPlace = firstText(row, TARGET_PLACE_FIELDS);
  if (sourcePlace || targetPlace) return compactRouteLabel(sourcePlace, targetPlace);
  return `Record ${index + 1}`;
}

function getRowCapabilityState(row) {
  const participants = getPeridotRowEntityParticipants(row);
  const sourcePlace = firstText(row, SOURCE_PLACE_FIELDS);
  const targetPlace = firstText(row, TARGET_PLACE_FIELDS);
  const mappedPlaces = getMappedPlaceValues(row);
  const hasPeople = participants.length > 0;
  const hasEntityRoute = rowHasPeridotEntityRelationship(row);
  const hasPlaces = mappedPlaces.length > 0;
  const hasPlaceRoute = Boolean(sourcePlace && targetPlace);
  const temporalCapability = getRowTimelineCapability(row);
  const hasDate = temporalCapability.hasTemporalEvidence;
  const hasCoordinates = hasAnyCoordinate(row) || hasMappedPlaceCoordinates(row);
  const hasEvidence = hasAnyEvidenceField(row);
  return {
    hasPeople,
    hasEntityRoute,
    hasPlaces,
    hasPlaceRoute,
    hasDate,
    hasCoordinates,
    hasEvidence,
    inspectorReady: hasAnySearchableContent(row),
    mapReady: hasPlaces || hasCoordinates,
    routeReady: hasPlaceRoute || Boolean(row?.mappable),
    networkReady: hasEntityRoute,
    timelineReady: temporalCapability.timelineReady,
    evidenceReady: hasEvidence,
    missingDate: !hasDate,
    missingCoordinates: !hasCoordinates,
  };
}

export function rowMatchesSearchCapabilityFilter(row, filterId) {
  const state = getRowCapabilityState(row);
  switch (filterId) {
    case 'inspector-ready':
      return state.inspectorReady;
    case 'map-ready':
      return state.mapReady;
    case 'route-ready':
      return state.routeReady;
    case 'network-ready':
      return state.networkReady;
    case 'timeline-ready':
      return state.timelineReady;
    case 'evidence-ready':
      return state.evidenceReady;
    case 'missing-date':
      return state.missingDate;
    case 'missing-coordinates':
      return state.missingCoordinates;
    default:
      return true;
  }
}

export function getCapabilityFilterLabel(filterId) {
  return CAPABILITY_FILTER_OPTIONS.find((option) => option.id === filterId)?.label || filterId;
}

function normalizeMetadataFieldId(value) {
  return asText(value).toLowerCase();
}

function metadataEntriesForCriterion(row, metadataField = '') {
  const requestedField = normalizeMetadataFieldId(metadataField);
  const entries = getSearchableEvidenceFieldEntries(row);
  if (!requestedField) return entries;

  return entries.filter((entry) => (
    normalizeMetadataFieldId(entry.key) === requestedField
    || normalizeMetadataFieldId(entry.label) === requestedField
  ));
}

function normalizeEntityPairValue(value) {
  return asText(value).toLowerCase();
}

const STRUCTURED_COUNT_ANCHOR_IDS = new Set(['peopleInRecord', 'placesInRecord']);
const STRUCTURED_COUNT_METRIC_IDS = new Set(['connectedEntities', 'connectedPlaces', 'records']);

function normalizeCountIdentity(value) {
  return asText(value).toLowerCase();
}

function personIdentityKey(participant = {}) {
  const id = normalizeCountIdentity(participant?.id || participant?.entityId);
  if (id) return `id:${id}`;
  const label = normalizeCountIdentity(participant?.label || participant?.value);
  return label ? `label:${label}` : '';
}

function placeIdentityKey(value) {
  const label = normalizeCountIdentity(value);
  return label ? `place:${label}` : '';
}

function ensureCountMetricEntry(map, key) {
  if (!key) return null;
  if (!map.has(key)) {
    map.set(key, {
      connectedEntities: new Set(),
      connectedPlaces: new Set(),
      records: new Set(),
    });
  }
  return map.get(key);
}

function normalizeAttachedCountCondition(condition, field) {
  if (!condition || typeof condition !== 'object') return null;

  const parsedThreshold = Number.parseInt(String(condition.threshold ?? '').trim(), 10);
  const threshold = Number.isFinite(parsedThreshold) ? Math.max(1, parsedThreshold) : 2;
  const anchor = field === 'person'
    ? 'thisPerson'
    : field === 'place'
      ? 'thisPlace'
      : (STRUCTURED_COUNT_ANCHOR_IDS.has(condition.anchor) ? condition.anchor : 'peopleInRecord');
  const metric = STRUCTURED_COUNT_METRIC_IDS.has(condition.metric)
    ? condition.metric
    : (anchor === 'thisPlace' || anchor === 'placesInRecord' ? 'connectedPlaces' : 'connectedEntities');

  return { anchor, metric, threshold };
}

export function buildStructuredCountContext(rows = []) {
  const safeRows = Array.isArray(rows) ? rows : [];
  const personMetrics = new Map();
  const placeMetrics = new Map();
  const personAliasToKey = new Map();

  safeRows.forEach((row, rowIndex) => {
    const rowKey = asText(row?.id || row?.recordId || row?.Record_ID || row?.Letter_ID) || `row:${rowIndex}`;
    const participantEntries = getPeridotRowEntityParticipantEntries(row);

    participantEntries.forEach((participant) => {
      const key = personIdentityKey(participant);
      if (!key) return;
      const label = normalizeCountIdentity(participant?.label || participant?.value);
      if (label && !personAliasToKey.has(label)) personAliasToKey.set(label, key);
      ensureCountMetricEntry(personMetrics, key)?.records.add(rowKey);
    });

    getPeridotRowEntityRelationships(row).forEach((relationship) => {
      const sourceKey = personIdentityKey({ id: relationship?.sourceId, label: relationship?.source });
      const targetKey = personIdentityKey({ id: relationship?.targetId, label: relationship?.target });
      if (!sourceKey || !targetKey || sourceKey === targetKey) return;
      ensureCountMetricEntry(personMetrics, sourceKey)?.connectedEntities.add(targetKey);
      ensureCountMetricEntry(personMetrics, targetKey)?.connectedEntities.add(sourceKey);
    });

    const structure = buildPeridotRecordStructure(row);
    structure.places.forEach((place) => {
      const pKey = placeIdentityKey(place?.value);
      if (!pKey) return;
      ensureCountMetricEntry(placeMetrics, pKey)?.records.add(rowKey);

      const subjectLabel = normalizeCountIdentity(place?.subject);
      const subjectId = normalizeCountIdentity(place?.subjectId);
      const subjectKey = subjectId
        ? `id:${subjectId}`
        : (personAliasToKey.get(subjectLabel) || (subjectLabel ? `label:${subjectLabel}` : ''));
      if (!subjectKey) return;

      ensureCountMetricEntry(personMetrics, subjectKey)?.connectedPlaces.add(pKey);
      ensureCountMetricEntry(placeMetrics, pKey)?.connectedEntities.add(subjectKey);
    });

    // Place-to-place connectivity remains conservative: only explicit Source/Target
    // route compatibility fields create a place connection. Multiple generalized
    // place assertions in one record are never paired automatically.
    const sourcePlace = firstText(row, SOURCE_PLACE_FIELDS);
    const targetPlace = firstText(row, TARGET_PLACE_FIELDS);
    const sourcePlaceKey = placeIdentityKey(sourcePlace);
    const targetPlaceKey = placeIdentityKey(targetPlace);
    if (sourcePlaceKey && targetPlaceKey && sourcePlaceKey !== targetPlaceKey) {
      ensureCountMetricEntry(placeMetrics, sourcePlaceKey)?.connectedPlaces.add(targetPlaceKey);
      ensureCountMetricEntry(placeMetrics, targetPlaceKey)?.connectedPlaces.add(sourcePlaceKey);
    }

    // Compatibility rows without participant-attributed place assertions can still
    // establish entity/place association through explicit Source/Target pairing.
    getPeridotRowEntityRelationships(row).forEach((relationship) => {
      const sourceKey = personIdentityKey({ id: relationship?.sourceId, label: relationship?.source });
      const targetKey = personIdentityKey({ id: relationship?.targetId, label: relationship?.target });
      if (sourcePlaceKey && sourceKey) {
        ensureCountMetricEntry(personMetrics, sourceKey)?.connectedPlaces.add(sourcePlaceKey);
        ensureCountMetricEntry(placeMetrics, sourcePlaceKey)?.connectedEntities.add(sourceKey);
      }
      if (targetPlaceKey && targetKey) {
        ensureCountMetricEntry(personMetrics, targetKey)?.connectedPlaces.add(targetPlaceKey);
        ensureCountMetricEntry(placeMetrics, targetPlaceKey)?.connectedEntities.add(targetKey);
      }
    });
  });

  const metricCount = (anchorType, key, metric) => {
    const map = anchorType === 'place' ? placeMetrics : personMetrics;
    return map.get(key)?.[metric]?.size || 0;
  };

  return Object.freeze({
    personAliasToKey,
    personMetrics,
    placeMetrics,
    metricCount,
  });
}

function personKeysForRow(row, context) {
  return Array.from(new Set(
    getPeridotRowEntityParticipantEntries(row)
      .map((participant) => {
        const directKey = personIdentityKey(participant);
        const label = normalizeCountIdentity(participant?.label || participant?.value);
        return directKey || context?.personAliasToKey?.get(label) || '';
      })
      .filter(Boolean),
  ));
}

function placeKeysForRow(row) {
  return Array.from(new Set(getMappedPlaceValues(row).map(placeIdentityKey).filter(Boolean)));
}

function matchedPersonKeysForCriterion(row, criterion, context) {
  return Array.from(new Set(
    getPeridotRowEntityParticipantEntries(row)
      .filter((participant) => valueMatchesMode(participant?.label, criterion.mode, criterion.value))
      .map((participant) => {
        const directKey = personIdentityKey(participant);
        const label = normalizeCountIdentity(participant?.label || participant?.value);
        return directKey || context?.personAliasToKey?.get(label) || '';
      })
      .filter(Boolean),
  ));
}

function matchedPlaceKeysForCriterion(row, criterion) {
  return Array.from(new Set(
    getMappedPlaceValues(row)
      .filter((value) => valueMatchesMode(value, criterion.mode, criterion.value))
      .map(placeIdentityKey)
      .filter(Boolean),
  ));
}

function rowMatchesAttachedCountCondition(row, criterion, context) {
  const condition = normalizeAttachedCountCondition(criterion?.countCondition, criterion?.field);
  if (!condition) return true;
  if (!context?.metricCount) return false;

  let anchorType = 'person';
  let anchorKeys = [];

  if (condition.anchor === 'thisPerson') {
    anchorType = 'person';
    anchorKeys = matchedPersonKeysForCriterion(row, criterion, context);
  } else if (condition.anchor === 'thisPlace') {
    anchorType = 'place';
    anchorKeys = matchedPlaceKeysForCriterion(row, criterion);
  } else if (condition.anchor === 'placesInRecord') {
    anchorType = 'place';
    anchorKeys = placeKeysForRow(row);
  } else {
    anchorType = 'person';
    anchorKeys = personKeysForRow(row, context);
  }

  return anchorKeys.some((key) => context.metricCount(anchorType, key, condition.metric) >= condition.threshold);
}

function rowMatchesEntityPairCriterion(row, criterion) {
  const firstMode = criterion.firstMode || 'exact';
  const secondMode = criterion.secondMode || 'contains';
  const firstValue = criterion.firstValue;
  const secondValue = criterion.secondValue;

  return getPeridotRowEntityRelationships(row).some((relationship) => {
    const source = asText(relationship.source);
    const target = asText(relationship.target);
    const sourceIdentity = normalizeEntityPairValue(source);
    const targetIdentity = normalizeEntityPairValue(target);
    if (!source || !target || !sourceIdentity || sourceIdentity === targetIdentity) return false;
    return (
      (valueMatchesMode(source, firstMode, firstValue) && valueMatchesMode(target, secondMode, secondValue))
      || (valueMatchesMode(target, firstMode, firstValue) && valueMatchesMode(source, secondMode, secondValue))
    );
  });
}

function valuesForStructuredField(row, field, metadataField = '') {
  if (field === 'person') return getPeridotRowEntityParticipants(row);
  if (field === 'place') return getMappedPlaceValues(row);
  if (field === 'routePlace') {
    return [compactRouteLabel(firstText(row, SOURCE_PLACE_FIELDS), firstText(row, TARGET_PLACE_FIELDS))];
  }
  if (field === 'routePeople') {
    return getPeridotRowEntityRelationshipLabels(row);
  }
  if (field === 'date') return getRowTemporalSearchValues(row);
  if (field === 'evidenceFieldPresent' || field === 'metadataFieldPresent') {
    return getSearchableEvidenceFieldEntries(row).map((entry) => entry.label);
  }
  if (field === 'evidence' || field === 'metadataValue') {
    return metadataEntriesForCriterion(row, metadataField).map((entry) => entry.value);
  }
  return collectSearchableFields(row).map((fieldRecord) => fieldRecord.value);
}

function criterionNeedsValue(mode) {
  return mode !== 'isEmpty' && mode !== 'isNotEmpty';
}

function valueMatchesMode(value, mode, query) {
  const text = asText(value);
  const q = asText(query);
  if (mode === 'isEmpty') return !text;
  if (mode === 'isNotEmpty') return Boolean(text);
  if (!q) return true;
  if (mode === 'exact') return text.toLowerCase() === q.toLowerCase();
  if (mode === 'startsWith') return text.toLowerCase().startsWith(q.toLowerCase());
  return text.toLowerCase().includes(q.toLowerCase());
}

function normalizeStructuredOperator(operator) {
  // `must` and `should` remain the persisted compatibility values. The Search
  // workspace renders them as explicit Required and Any-of groups rather than
  // a misleading left-to-right Boolean sequence.
  return ['must', 'should', 'exclude'].includes(operator) ? operator : 'must';
}

function normalizeStructuredField(field) {
  if (field === 'evidence') return 'metadataValue';
  if (field === 'evidenceFieldPresent') return 'metadataFieldPresent';
  return field || 'any';
}

function normalizeStructuredCriteria(criteria = []) {
  return (Array.isArray(criteria) ? criteria : [])
    .map((criterion) => {
      const field = normalizeStructuredField(criterion?.field);
      return {
        operator: normalizeStructuredOperator(criterion?.operator),
        field,
        metadataField: asText(criterion?.metadataField),
        mode: criterion?.mode || 'contains',
        value: asText(criterion?.value),
        firstMode: criterion?.firstMode || 'exact',
        firstValue: asText(criterion?.firstValue),
        secondMode: criterion?.secondMode || 'contains',
        secondValue: asText(criterion?.secondValue),
        countCondition: normalizeAttachedCountCondition(criterion?.countCondition, field),
      };
    })
    .filter((criterion) => {
      if (criterion.field === 'frequency') return false;
      if (criterion.field === 'entityPair') return criterion.firstValue && criterion.secondValue;
      return !criterionNeedsValue(criterion.mode) || criterion.value;
    });
}

function rowMatchesStructuredCriterionPrimary(row, criterion) {
  if (criterion.field === 'entityPair') {
    return rowMatchesEntityPairCriterion(row, criterion);
  }
  if (criterion.field === 'capability') {
    if (!criterionNeedsValue(criterion.mode)) {
      return criterion.mode === 'isNotEmpty';
    }
    const query = asText(criterion.value).toLowerCase();
    const matchingOptions = CAPABILITY_FILTER_OPTIONS.filter((option) => (
      option.id.toLowerCase().includes(query)
      || option.label.toLowerCase().includes(query)
      || option.shortLabel.toLowerCase().includes(query)
    ));
    return matchingOptions.some((option) => rowMatchesSearchCapabilityFilter(row, option.id));
  }
  const values = valuesForStructuredField(row, criterion.field, criterion.metadataField);
  if (criterion.mode === 'isEmpty') return values.every((value) => !asText(value));
  if (criterion.mode === 'isNotEmpty') return values.some((value) => asText(value));
  return values.some((value) => valueMatchesMode(value, criterion.mode, criterion.value));
}

function rowMatchesStructuredCriterion(row, criterion, countContext = null) {
  if (!rowMatchesStructuredCriterionPrimary(row, criterion)) return false;
  return rowMatchesAttachedCountCondition(row, criterion, countContext);
}

export function rowMatchesStructuredCriteria(row, criteria = [], options = {}) {
  const normalizedCriteria = normalizeStructuredCriteria(criteria);
  if (!normalizedCriteria.length) return true;
  const countContext = options?.countContext || null;

  const mustCriteria = normalizedCriteria.filter((criterion) => criterion.operator === 'must');
  const shouldCriteria = normalizedCriteria.filter((criterion) => criterion.operator === 'should');
  const excludeCriteria = normalizedCriteria.filter((criterion) => criterion.operator === 'exclude');

  const passesMust = mustCriteria.every((criterion) => rowMatchesStructuredCriterion(row, criterion, countContext));
  const passesShould = shouldCriteria.length === 0 || shouldCriteria.some((criterion) => rowMatchesStructuredCriterion(row, criterion, countContext));
  const passesExclude = excludeCriteria.every((criterion) => !rowMatchesStructuredCriterion(row, criterion, countContext));

  return passesMust && passesShould && passesExclude;
}

function structuredOperatorLabel(operator) {
  if (operator === 'should') return 'OR';
  if (operator === 'exclude') return 'EXCLUDING';
  return 'AND';
}

function describeStructuredCriterionMatch(row, criterion) {
  if (criterion.operator === 'exclude') return null;
  if (!rowMatchesStructuredCriterionPrimary(row, criterion)) return null;
  const fieldLabel = {
    any: 'Structured criterion',
    person: 'Structured person',
    place: 'Structured place',
    routePlace: 'Structured route place',
    routePeople: 'Structured route people',
    entityPair: 'Connected entity pair',
    date: 'Structured date',
    metadataValue: 'Evidence value',
    metadataFieldPresent: 'Evidence field',
    evidence: 'Evidence value',
    evidenceFieldPresent: 'Evidence field',
    capability: 'Structured capability',
  }[criterion.field] || 'Structured criterion';
  const operatorPrefix = structuredOperatorLabel(criterion.operator);


  if (criterion.field === 'entityPair') {
    return {
      label: `${operatorPrefix}: ${fieldLabel}`,
      value: `${criterion.firstValue} + ${criterion.secondValue}`,
    };
  }

  if (criterion.field === 'capability') {
    const matched = CAPABILITY_FILTER_OPTIONS.find((option) => (
      option.id === criterion.value || option.label.toLowerCase() === asText(criterion.value).toLowerCase()
    ));
    return { label: `${operatorPrefix}: ${fieldLabel}`, value: matched?.label || criterion.value || criterion.mode };
  }

  const values = valuesForStructuredField(row, criterion.field, criterion.metadataField);
  if (criterion.mode === 'isEmpty') return { label: `${operatorPrefix}: ${fieldLabel}`, value: 'is empty' };
  if (criterion.mode === 'isNotEmpty') {
    const firstValue = values.find((value) => asText(value));
    return { label: `${operatorPrefix}: ${fieldLabel}`, value: asText(firstValue) || 'is not empty' };
  }
  const matchedValue = values.find((value) => valueMatchesMode(value, criterion.mode, criterion.value));
  return { label: `${operatorPrefix}: ${fieldLabel}`, value: asText(matchedValue) || criterion.value };
}

function buildMatchedFields(row, appliedFilters) {
  const matches = [];
  const keywordMatch = findFirstFieldMatch(row, appliedFilters.search, []);
  if (keywordMatch) {
    matches.push({
      label: `Keyword in ${keywordMatch.label}`,
      value: keywordMatch.value,
    });
  }

  const personQuery = asText(appliedFilters.personFilter);
  if (personQuery) {
    const participant = getPeridotRowEntityParticipants(row).find((value) => includesNeedle(value, personQuery));
    if (participant) matches.push({ label: 'Person / entity', value: participant });
  }

  const placeQuery = asText(appliedFilters.placeFilter);
  if (placeQuery) {
    const placeMatch = getMappedPlaceEntries(row).find((entry) => includesNeedle(entry?.value, placeQuery));
    if (placeMatch) matches.push({ label: `Place in ${asText(placeMatch.label) || 'mapped place'}`, value: asText(placeMatch.value) });
  }

  const routePlaceQuery = asText(appliedFilters.routePlaceFilter);
  if (routePlaceQuery) {
    const placeRoute = compactRouteLabel(firstText(row, SOURCE_PLACE_FIELDS), firstText(row, TARGET_PLACE_FIELDS));
    if (includesNeedle(placeRoute, routePlaceQuery)) matches.push({ label: 'Route place', value: placeRoute });
  }

  const routePeopleQuery = asText(appliedFilters.routePeopleFilter);
  if (routePeopleQuery) {
    const peopleRoute = getPeridotRowEntityRelationshipLabels(row).find((label) => includesNeedle(label, routePeopleQuery));
    if (peopleRoute) matches.push({ label: 'Entity relationship', value: peopleRoute });
  }

  const capabilityMatches = (appliedFilters.capabilityFilters || [])
    .filter((filterId) => rowMatchesSearchCapabilityFilter(row, filterId))
    .map((filterId) => ({ label: 'Capability', value: getCapabilityFilterLabel(filterId) }));

  const structuredMatches = normalizeStructuredCriteria(appliedFilters.structuredCriteria)
    .map((criterion) => describeStructuredCriterionMatch(row, criterion))
    .filter(Boolean);

  return matches.concat(capabilityMatches, structuredMatches).slice(0, 5);
}

function buildCapabilityBadges(row) {
  const state = getRowCapabilityState(row);
  const badges = [];
  if (state.inspectorReady) badges.push('Inspector-ready');
  if (state.mapReady) badges.push('Map-relevant');
  if (state.networkReady) badges.push('Network-ready');
  if (state.timelineReady) badges.push('Timeline-ready');
  if (state.evidenceReady) badges.push('Evidence-rich');
  return badges.slice(0, 5);
}


/*
 * Evidence facets retain the field/value relationship of canonical mapped
 * Evidence assertions. Each returned field group can therefore add a precise
 * refinement such as Language = Italian rather than a broad text search for
 * “Italian” anywhere in a record.
 */
export function buildPeridotMetadataFacetGroups(rows = [], options = {}) {
  const fieldLimit = Number.isFinite(options.fieldLimit)
    ? Math.max(1, options.fieldLimit)
    : Number.POSITIVE_INFINITY;
  const valueLimit = Number.isFinite(options.valueLimit)
    ? Math.max(1, options.valueLimit)
    : Number.POSITIVE_INFINITY;
  const fields = new Map();

  (Array.isArray(rows) ? rows : []).forEach((row) => {
    const seenValuesInRow = new Set();
    const seenFieldsInRow = new Set();
    getSearchableEvidenceFieldEntries(row).forEach((entry) => {
      const key = asText(entry.key) || asText(entry.label);
      const label = asText(entry.label) || key;
      const value = asText(entry.value);
      if (!key || !label || !value) return;

      const fieldIdentity = `${key}\u0000${label}`;
      const valueIdentity = `${fieldIdentity}\u0000${value}`;
      if (seenValuesInRow.has(valueIdentity)) return;
      seenValuesInRow.add(valueIdentity);

      if (!fields.has(fieldIdentity)) {
        fields.set(fieldIdentity, {
          id: `metadata-${key}`,
          key,
          label,
          values: new Map(),
          recordCount: 0,
        });
      }

      const field = fields.get(fieldIdentity);
      if (!seenFieldsInRow.has(fieldIdentity)) {
        field.recordCount += 1;
        seenFieldsInRow.add(fieldIdentity);
      }
      field.values.set(value, (field.values.get(value) || 0) + 1);
    });
  });

  return Array.from(fields.values())
    .map((field) => ({
      id: field.id,
      key: field.key,
      label: field.label,
      recordCount: field.recordCount,
      items: facetItemsFromMap(field.values, valueLimit),
    }))
    .filter((field) => field.items.length > 0)
    .sort((a, b) => a.label.localeCompare(b.label))
    .slice(0, fieldLimit);
}

export function buildPeridotSearchFacets(rows = [], options = {}) {
  const limit = Number.isFinite(options.limit)
    ? Math.max(1, options.limit)
    : Number.POSITIVE_INFINITY;
  const people = new Map();
  const places = new Map();
  const placeRoutes = new Map();
  const entityRelationships = new Map();
  const years = new Map();
  const evidenceFields = new Map();

  rows.forEach((row) => {
    const participants = getPeridotRowEntityParticipants(row);
    const sourcePlace = firstText(row, SOURCE_PLACE_FIELDS);
    const targetPlace = firstText(row, TARGET_PLACE_FIELDS);
    const temporalYears = getRowTemporalYears(row);
    participants.forEach((participant) => addFacetCount(people, participant));
    getPeridotRowEntityRelationshipLabels(row).forEach((relationshipLabel) => addFacetCount(entityRelationships, relationshipLabel));
    getMappedPlaceValues(row).forEach((place) => addFacetCount(places, place));
    if (sourcePlace || targetPlace) addFacetCount(placeRoutes, compactRouteLabel(sourcePlace, targetPlace));
    Array.from(new Set(temporalYears)).forEach((year) => addFacetCount(years, String(year).slice(0, 4)));
    Array.from(new Set(
      getSearchableEvidenceFieldEntries(row)
        .map((entry) => asText(entry.label))
        .filter(Boolean),
    )).forEach((label) => {
      addFacetCount(evidenceFields, label);
    });
  });

  const capabilityItems = CAPABILITY_FILTER_OPTIONS.map((option) => ({
    value: option.id,
    label: option.label,
    count: rows.filter((row) => rowMatchesSearchCapabilityFilter(row, option.id)).length,
  })).filter((item) => item.count > 0);

  return [
    { id: 'people', label: 'People / entities', type: 'person', items: facetItemsFromMap(people, limit) },
    { id: 'places', label: 'Places', type: 'place', items: facetItemsFromMap(places, limit) },
    { id: 'placeRoutes', label: 'Place routes', type: 'routePlace', items: facetItemsFromMap(placeRoutes, limit) },
    { id: 'entityRelationships', label: 'Entity relationships', type: 'routePeople', items: facetItemsFromMap(entityRelationships, limit) },
    { id: 'years', label: 'Years', type: 'year', items: facetItemsFromMap(years, limit) },
    { id: 'capabilities', label: 'Capabilities', type: 'capability', items: capabilityItems },
    { id: 'metadataFields', label: 'Evidence fields present', type: 'metadataFieldPresent', items: facetItemsFromMap(evidenceFields, limit) },
  ].filter((group) => group.items.length > 0);
}

export function buildPeridotSearchResults(rows = [], appliedFilters = {}, options = {}) {
  const limit = Math.max(1, options.limit ?? 50);
  return rows.slice(0, limit).map((row, index) => {
    const relationships = getPeridotRowEntityRelationships(row);
    const participants = getPeridotRowEntityParticipants(row);
    const relationshipLabels = relationships.map((relationship) => {
      const connector = relationship.direction === 'directed' ? '→' : '—';
      return `${relationship.source} ${connector} ${relationship.target}`;
    });
    const firstRelationship = relationships[0] || null;
    const sourcePerson = firstRelationship?.source || participants[0] || '';
    const targetPeople = Array.from(new Set(relationships.map((relationship) => relationship.target).filter(Boolean)));
    const targetPerson = targetPeople.join(' · ');
    const sourcePlace = firstText(row, SOURCE_PLACE_FIELDS);
    const targetPlace = firstText(row, TARGET_PLACE_FIELDS);
    const displayDate = getRowTemporalDisplayLabels(row).slice(0, 2).join(' · ') || firstText(row, DATE_FIELDS) || 'Undated';
    const matchedFields = buildMatchedFields(row, appliedFilters);
    return {
      id: row?.id || row?.recordId || row?.Record_ID || row?.Letter_ID || `search-result-${index}`,
      index,
      row,
      title: buildResultTitle(row, index),
      displayDate,
      peopleRoute: relationshipLabels.join(' · '),
      peopleRoutes: relationshipLabels,
      networkParticipants: participants,
      placeRoute: compactRouteLabel(sourcePlace, targetPlace),
      sourcePerson,
      targetPerson,
      sourcePlace,
      targetPlace,
      matchedFields,
      capabilityBadges: buildCapabilityBadges(row),
    };
  });
}
