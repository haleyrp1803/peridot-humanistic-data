/*
 * Public Peridot CSV template contract.
 * 
 * This file defines the one-file template columns, field groups, capability labels, minimum admission rules, upload tips, and small capability predicates used to explain what each row can support.
 * 
 * Important relationships:
 * - `PeridotDataWorkspace.jsx` exposes the template to users.
 * - `peridotCsvNormalizer.js` converts template rows into internal app shapes.
 * - `peridotCsvValidation.js` uses this contract to summarize accepted rows and capabilities.
 * 
 * Maintenance cautions:
 * - This file represents public data-entry policy. Column renames or admission-rule changes affect users' saved templates and documentation.
 */

/**
 * Peridot single-CSV data contract.
 *
 * This module records the agreed schema and capability model for the
 * standardized Peridot CSV upload workflow. The public template remains
 * correspondence-oriented for backward compatibility, while flexible imports
 * now support broader record, point/site, route, relationship, and time-series data.
 *
 * Pass 1 scope:
 * - define the template column names;
 * - classify fields by purpose;
 * - document the minimum record rules;
 * - provide small pure helpers that later importer/validation passes can reuse;
 * - do not wire this file into the UI yet;
 * - do not remove the legacy three-file upload path yet.
 *
 * Product rule:
 * Peridot should behave as a database with strong visualization capabilities.
 * Messy or incomplete historical data should be accepted when it contains
 * enough source/target information to be a meaningful record. Rows that cannot
 * support a given visualization should be flagged for the user, not silently
 * discarded.
 *
 * Data-cleaning rule:
 * Peridot does not standardize person names, place names, dates, titles,
 * relationships, topics, languages, or controlled vocabularies. Users are
 * responsible for cleaning and standardizing their data outside the app.
 */

import { parsePeridotCoordinatePair, parsePeridotTemporalRange, parsePeridotTemporalValue } from './peridotDataCapabilityAudit.js';

/**
 * The public template column names are intentionally preserved exactly as
 * supplied in the current Peridot CSV template.
 */
export const PERIDOT_TEMPLATE_COLUMNS = Object.freeze([
  "Archive",
  "Collection",
  "Page(s)",
  "Date",
  "Source_Name",
  "Source_Title",
  "Source_Location",
  "Source_Latitude",
  "Source_Longitude",
  "Target_Name",
  "Target_Title",
  "Target_Location",
  "Target_Latitude",
  "Target_Longitude",
  "Relationship",
  "Topic",
  "Language",
  "Transcription",
  "Notes",
  "Link(s)",
]);

/**
 * Field groupings for user-facing documentation, validation summaries,
 * and later upload-page guidance.
 */
export const PERIDOT_FIELD_GROUPS = Object.freeze({
  networkLogic: Object.freeze({
    label: "Network logic",
    fields: Object.freeze(["Date", "Source_Name", "Target_Name"]),
    note:
      "These fields help Peridot build entity relationships, timelines, filters, and network edges when the mapped values are present.",
  }),

  mapping: Object.freeze({
    label: "Mapping",
    fields: Object.freeze([
      "Source_Location",
      "Source_Latitude",
      "Source_Longitude",
      "Target_Location",
      "Target_Latitude",
      "Target_Longitude",
    ]),
    note:
      "Coordinates are not required for upload. Rows need usable point coordinates or usable source and target coordinates to appear on map visualizations.",
  }),

  recommendedResearchMetadata: Object.freeze({
    label: "Recommended research metadata",
    fields: Object.freeze([
      "Archive",
      "Collection",
      "Page(s)",
      "Source_Title",
      "Target_Title",
      "Relationship",
      "Topic",
      "Language",
    ]),
    note:
      "These fields make Inspector views, charts, Advanced Search, and exports more useful.",
  }),

  optionalRichMetadata: Object.freeze({
    label: "Optional rich metadata",
    fields: Object.freeze(["Transcription", "Notes", "Link(s)"]),
    note:
      "These fields support close reading, citation, documentation, search, and external-reference workflows.",
  }),
});

/**
 * Later validation should treat a row as an accepted Peridot record if it has
 * any meaningful database content, while still distinguishing which
 * visualization capabilities that row can support.
 *
 * Accepted record shapes include:
 *
 * 1. source and target person/entity names;
 * 2. source-side and target-side place information;
 * 3. one point/site place or coordinate role; or
 * 4. generic evidence, chart, temporal, or citation content.
 *
 * Date and coordinates are capability-enabling fields, not universal admission
 * criteria. Generic evidence/chart records should be accepted into the active
 * dataset even when they are not map-ready or network-ready.
 */
export const PERIDOT_MINIMUM_RECORD_RULES = Object.freeze({
  acceptedRecord:
    "A row is accepted when it has relationship fields, point/site fields, route/place fields, or generic evidence/chart content.",
  personPair: Object.freeze(["Source_Name", "Target_Name"]),
  sourcePlaceFields: Object.freeze([
    "Source_Location",
    "Source_Latitude",
    "Source_Longitude",
  ]),
  targetPlaceFields: Object.freeze([
    "Target_Location",
    "Target_Latitude",
    "Target_Longitude",
  ]),
  genericEvidence:
    "Any non-empty uploaded row will be available as a database record for evidence, search, charts, and export when it is accepted.",
});

/**
 * Capability labels used by the post-upload validation summary.
 *
 * A single row may support some capabilities and not others.
 * This makes incomplete data legible without rejecting it unnecessarily.
 */
export const PERIDOT_ROW_CAPABILITIES = Object.freeze({
  inspectorReady: Object.freeze({
    label: "Available in Inspector",
    note:
      "The record has enough evidence content to remain available in Inspector and Export where possible."
  }),

  peopleNetworkReady: Object.freeze({
    label: "Available for People/Entity Network",
    note:
      "The record has source and target names and can contribute to person/entity graph views."
  }),

  placeNetworkReady: Object.freeze({
    label: "Available for route/place relationships",
    note:
      "The record has source-side and target-side place information and can contribute to route or place-relationship views."
  }),

  pointMapReady: Object.freeze({
    label: "Available for Point Map",
    note:
      "The record has one valid point coordinate pair and can render as a point-location record."
  }),

  routeMapReady: Object.freeze({
    label: "Available for Route Map",
    note:
      "The record has valid source and target coordinate pairs and can render as a geographic route."
  }),

  mapReady: Object.freeze({
    label: "Available for map visualizations",
    note:
      "The record has valid point coordinates or valid source and target coordinates for map rendering."
  }),

  timelineReady: Object.freeze({
    label: "Available for Timeline",
    note:
      "The record has a date value or date range Peridot can parse for sorting, filtering, or playback."
  }),

  analyticsReady: Object.freeze({
    label: "Available for charts",
    note:
      "The record has accepted metadata that Chart Visualizations may summarize exactly as entered."
  }),

  exportReady: Object.freeze({
    label: "Available for export",
    note:
      "The accepted uploaded record can be included in export workflows."
  }),
});

/**
 * Column mapping from public template fields to the internal concepts later
 * importer passes should normalize toward.
 */
export const PERIDOT_TEMPLATE_TO_INTERNAL_MEANING = Object.freeze({
  Source_Name: "source entity / correspondent",
  Target_Name: "target entity / correspondent",
  Source_Location: "source place",
  Target_Location: "target/inferred target place",
  Source_Latitude: "source latitude",
  Source_Longitude: "source longitude",
  Target_Latitude: "target latitude",
  Target_Longitude: "target longitude",
  Date: "sortable/displayable record date when parseable",
  Relationship: "relationship metadata",
  Topic: "topic metadata",
  Language: "language metadata",
  Archive: "citation/provenance metadata",
  Collection: "citation/provenance metadata",
  "Page(s)": "citation/provenance metadata",
  Source_Title: "source role/title metadata",
  Target_Title: "target role/title metadata",
  Transcription: "Inspector display metadata",
  Notes: "Inspector display metadata",
  "Link(s)": "Inspector display metadata or external-reference metadata",
});

/**
 * Upload-page tips. These should remain concise enough for the Data Inputs
 * panel, with longer guidance deferred to documentation if needed.
 */
export const PERIDOT_UPLOAD_TIPS = Object.freeze([
  "Each row should represent one record, document, site, event, observation, measurement, relationship, or correspondence item.",
  "Peridot accepts useful records first, then reports which tools the mapped fields can support.",
  "Coordinates are not required for upload. Records need valid point coordinates or valid source/target coordinates to appear on map visualizations.",
  "Peridot treats names, places, topics, relationships, languages, and other labels exactly as entered.",
  "For cleaner networks, filters, maps, and charts, standardize names, places, and categories before upload.",
  "Records with unparseable or missing dates will be available for search, Inspector, charts, or export when they contain other useful evidence. They may not participate in timeline playback.",
]);

export const PERIDOT_VALIDATION_SUMMARY_COPY = Object.freeze({
  uploadAcceptedHeading: "Upload accepted. Tool availability depends on mapped fields.",
  preservedRecordsNotice:
    "Accepted records will be available for search, Inspector, charts, and export where their mapped fields support those tools, even when they are not ready for every visualization. Tool availability depends on the mapped fields each record contains.",
  noCleaningNotice:
    "Peridot does not clean, merge, or standardize uploaded values. Charts, filters, labels, and networks use values exactly as entered.",
});

/**
 * Return true when a cell-like value contains non-whitespace content.
 */
export function hasValue(value) {
  return value !== null && value !== undefined && String(value).trim() !== "";
}

/**
 * Return true when a value can be treated as a latitude.
 */
export function isValidLatitude(value) {
  if (!hasValue(value)) return false;
  const number = Number(value);
  return Number.isFinite(number) && number >= -90 && number <= 90;
}

/**
 * Return true when a value can be treated as a longitude.
 */
export function isValidLongitude(value) {
  if (!hasValue(value)) return false;
  const number = Number(value);
  return Number.isFinite(number) && number >= -180 && number <= 180;
}

/**
 * Return true when a row has source and target person names.
 */
export function hasPersonPair(row) {
  return hasValue(row?.Source_Name) && hasValue(row?.Target_Name);
}

/**
 * Return true when a row has a valid coordinate pair for one endpoint.
 */
export function hasCoordinatePair(row, latitudeField, longitudeField) {
  return isValidLatitude(row?.[latitudeField]) && isValidLongitude(row?.[longitudeField]);
}

/**
 * Return true when a row has any usable place information for one endpoint.
 * Place names and coordinate pairs both count as place information.
 */
export function hasEndpointPlaceInformation(row, locationField, latitudeField, longitudeField) {
  return (
    hasValue(row?.[locationField]) ||
    hasCoordinatePair(row, latitudeField, longitudeField)
  );
}

/**
 * Return true when a row has a valid combined coordinate-pair field.
 * Peridot coordinate-pair uploads are latitude-first, longitude-second.
 */
export function hasCoordinatePairField(row, coordinateField) {
  return Boolean(parsePeridotCoordinatePair(row?.[coordinateField]));
}

/**
 * Return true when a row has any usable place information for a point/site record.
 */
export function hasPointPlaceInformation(row) {
  return (
    hasValue(row?.Point_Place) ||
    hasCoordinatePair(row, "Point_Latitude", "Point_Longitude") ||
    hasCoordinatePairField(row, "Point_Coordinates")
  );
}

/**
 * Return true when a row has source-side and target-side place information.
 */
export function hasPlacePair(row) {
  return (
    hasEndpointPlaceInformation(
      row,
      "Source_Location",
      "Source_Latitude",
      "Source_Longitude"
    ) || hasCoordinatePairField(row, "Source_Coordinates")
  ) && (
    hasEndpointPlaceInformation(
      row,
      "Target_Location",
      "Target_Latitude",
      "Target_Longitude"
    ) || hasCoordinatePairField(row, "Target_Coordinates")
  );
}

/**
 * Return true when a row has valid point coordinates.
 */
export function hasMappablePointCoordinate(row) {
  return (
    hasCoordinatePair(row, "Point_Latitude", "Point_Longitude") ||
    hasCoordinatePairField(row, "Point_Coordinates")
  );
}

/**
 * Return true when a row has valid source and target coordinate pairs.
 * This is the stricter route-rendering capability, not the upload-admission rule.
 */
export function hasMappableRouteCoordinatePair(row) {
  return (
    (hasCoordinatePair(row, "Source_Latitude", "Source_Longitude") || hasCoordinatePairField(row, "Source_Coordinates")) &&
    (hasCoordinatePair(row, "Target_Latitude", "Target_Longitude") || hasCoordinatePairField(row, "Target_Coordinates"))
  );
}

/**
 * Return true when a row has valid point or route coordinates.
 */
export function hasMappableCoordinatePair(row) {
  return hasMappablePointCoordinate(row) || hasMappableRouteCoordinatePair(row);
}

function hasUsableCustomInspectorField(row) {
  const fields = Array.isArray(row?.customInspectorFields) ? row.customInspectorFields : [];
  return fields.some((field) => hasValue(field?.value) || hasValue(field?.label) || hasValue(field?.sourceColumn));
}

function hasUsableOriginalUploadedValue(row) {
  const original = row?.originalUploadedRow;
  if (!original || typeof original !== 'object' || Array.isArray(original)) return false;
  return Object.values(original).some(hasValue);
}

function isInternalBookkeepingKey(key) {
  return [
    'customInspectorFields',
    'ignoredUploadedColumns',
    'originalUploadedRow',
    'originalTemplateRow',
    'peridotCapabilities',
  ].includes(key);
}

/**
 * Return true when a row has enough content to remain useful as a database
 * record even if it cannot support maps or networks. This is the generic
 * chart/evidence admission path used by time-series, catalogue, table, and
 * source/citation datasets.
 */
export function hasGenericEvidenceRecord(row) {
  if (!row || typeof row !== 'object') return false;

  const hasDirectValue = Object.entries(row).some(([key, value]) => {
    if (isInternalBookkeepingKey(key)) return false;
    if (Array.isArray(value)) return value.some(hasValue);
    if (value && typeof value === 'object') return false;
    return hasValue(value);
  });

  return hasDirectValue || hasUsableCustomInspectorField(row) || hasUsableOriginalUploadedValue(row);
}

/**
 * Return true when a row satisfies the minimum Peridot record rule.
 */
export function isAcceptedPeridotRecord(row) {
  return hasPersonPair(row) || hasPlacePair(row) || hasPointPlaceInformation(row) || hasGenericEvidenceRecord(row);
}

/**
 * Return normalized temporal information for the public Peridot Date field.
 *
 * This accepts exact dates, year/month precision, year-only values, circa years,
 * and simple year ranges. Unparseable values are preserved as display evidence
 * but are not timeline-ready.
 */
export function getPeridotDateCapability(row) {
  const hasStartOrEnd = hasValue(row?.Date_Start) || hasValue(row?.Date_End);

  const temporal = hasStartOrEnd
    ? parsePeridotTemporalRange({
        startValue: row?.Date_Start,
        endValue: row?.Date_End,
        displayValue: row?.Date_Display || row?.Date,
      })
    : parsePeridotTemporalValue(row?.Date || row?.Date_Display);

  return Object.freeze({
    timelineReady: temporal.isSortable,
    hasInterval: temporal.isInterval,
    hasClosedRange: temporal.rangeKind === 'closedRange',
    temporal,
  });
}

/**
 * Return true when a row has a Date value Peridot can sort/filter.
 */
export function hasMachineReadableDate(row) {
  return getPeridotDateCapability(row).timelineReady;
}

/**
 * Return row-level visualization capabilities under the agreed permissive model.
 */
export function getPeridotRowCapabilities(row) {
  const accepted = isAcceptedPeridotRecord(row);

  return Object.freeze({
    inspectorReady: accepted,
    peopleNetworkReady: hasPersonPair(row),
    placeNetworkReady: hasPlacePair(row),
    pointMapReady: hasMappablePointCoordinate(row),
    routeMapReady: hasMappableRouteCoordinatePair(row),
    mapReady: hasMappableCoordinatePair(row),
    timelineReady: hasMachineReadableDate(row),
    analyticsReady: accepted,
    exportReady: accepted,
  });
}

/**
 * Return any public template columns missing from a parsed CSV header.
 */
export function getMissingPeridotTemplateColumns(headers) {
  const provided = new Set((headers || []).map((header) => String(header).trim()));

  return PERIDOT_TEMPLATE_COLUMNS.filter((column) => !provided.has(column));
}
