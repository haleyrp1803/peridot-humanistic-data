/*
 * React entry point.
 *
 * This file mounts the Peridot app into the DOM. It should remain minimal:
 * import the shared stylesheet plus extracted component/workspace layers in their
 * deliberate cascade order, import `App`, and render inside React Strict Mode.
 *
 * Stylesheet order is a functional contract:
 * shared rules -> non-color foundations -> shared components (buttons, forms, cards, panels) -> Inspector -> Analytics -> Search ->
 * Mapping -> Learn More -> Tutorial -> global feedback modal. Do not remove an extracted stylesheet import when
 * adding a later layer; omitted imports can make an entire workspace fall back
 * to bare structural markup.
 */

import React, { Suspense, lazy } from 'react';
import ReactDOM from 'react-dom/client';
import { PeridotLoadingGem, DEFAULT_PERIDOT_LOADER_THEME } from './PeridotLoadingGem.jsx';

// Load the large application bundle asynchronously so the branded loading
// emblem can appear during genuine initial JS/module loading, without
// imposing a fixed artificial waiting period.
const App = lazy(() => import('./App.jsx'));

import './index.css';
import './PeridotBootLoader.css';
// Central non-color foundations; existing workspace styles retain cascade precedence.
import './styles/foundations/tokens.css';
// Opt-in editorial typography roles and font loading (V2a).
import './styles/foundations/typography.css';
// Shared buttons follow foundations and precede workspace-specific overrides.
import './styles/components/buttons.css';
// Shared form controls; workspace-specific forms continue to override these.
import './styles/components/forms.css';
// Shared cards and responsive card grids; specialized panels retain workspace ownership.
import './styles/components/cards.css';
// Shared workspace frames and cross-component surface ornaments.
import './styles/components/panels.css';
import './InspectorPanel.css';
import './AnalyticsPanel.css';
import './PeridotSearchWorkspace.css';
import './PeridotColumnMappingModal.css';
import './PeridotLearnMoreWorkspace.css';
import './PeridotTutorial.css';
import './PeridotFeedbackForm.css';

import { applyPeridotThemeVariables } from './peridotTheme.js';
import { applyPeridotColorVariables } from './peridotColorPalette.js';

applyPeridotThemeVariables();
applyPeridotColorVariables();

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <Suspense fallback={(
      <div className={`peridot-boot-loader peridot-loader-theme-${DEFAULT_PERIDOT_LOADER_THEME}`} role="status" aria-label="Loading Peridot">
        <PeridotLoadingGem />
        <span className="peridot-boot-loader-label">Loading Peridot…</span>
      </div>
    )}>
      <App />
    </Suspense>
  </React.StrictMode>
);
