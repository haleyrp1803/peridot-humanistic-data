/*
 * Navigation redesign Pass 2.
 *
 * Main visualization workspace.
 *
 * This component coordinates the compact local visualization navigation, map/network/chart/timeline stage, capability-unavailable states, contextual Export action, and bottom Timeline scrubber.
 * 
 * Important relationships:
 * - `App.jsx` owns the current data, selected visualization, map stage, export handlers, and timeline state passed here.
 * - `AnalyticsPanel.jsx` owns chart controls/rendering but registers chart export with the shared contextual export action.
 * - `timelinePlaybackComponents.jsx` renders the bottom scrubber used here.
 * 
 * Maintenance cautions:
 * - This is now a key workspace-coordination file. Keep behavior changes narrow and test maps, networks, charts, timeline, and export after edits.
 * - Export remains contextual to the active visualization and is visually separated from navigation.
 *
 * Scope contract:
 * - This component does not derive the visible dataset. It receives already-
 *   scoped graph/map/chart props from `App.jsx`.
 * - The bottom timeline scrubber changes global App state; those changes flow
 *   back through graph derivation before this workspace renders the next view.
 * - Contextual Export should export the same scoped visualization state that is
 *   currently rendered. Do not point export actions at raw uploaded rows unless
 *   adding a separate, explicitly labeled full-dataset export.
 * - Chart export is registered by `AnalyticsPanel.jsx`; map/network export is
 *   passed from App. The header menu switches between those contexts.
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

import { AnalyticsPanelContent } from './AnalyticsPanel.jsx';
import { PeridotTimelineII } from './PeridotTimelineII.jsx';
import { PeridotSharedChronologyAdapter } from './PeridotSharedChronologyAdapter.jsx';

const VISUALIZATION_TOOLS = Object.freeze({
  GEOGRAPHIC_MAP: 'geographic-map',
  FORCE_NETWORK: 'force-network',
  CHART_WORKSPACE: 'chart-workspace',
  TIMELINE_II: 'timeline-ii',
  CAPABILITY_SUMMARY: 'capability-summary',
});

function chartTypeFromToolKey(toolKey) {
  return String(toolKey || '').startsWith('chart:') ? String(toolKey).slice(6) : null;
}

function numberLabel(value) {
  return Number.isFinite(value) ? String(value) : '0';
}




function FloatingOrnamentArrowToggle({
  anchorRef,
  placement = 'bottom',
  expanded,
  onClick,
  expandedLabel,
  collapsedLabel,
  expandedArrow,
  collapsedArrow,
}) {
  const [anchorRect, setAnchorRect] = useState(null);

  useEffect(() => {
    if (typeof window === 'undefined') return undefined;

    let frameId = null;
    const updateRect = () => {
      if (frameId) window.cancelAnimationFrame(frameId);
      frameId = window.requestAnimationFrame(() => {
        const node = anchorRef?.current;
        setAnchorRect(node ? node.getBoundingClientRect() : null);
      });
    };

    updateRect();
    window.addEventListener('resize', updateRect);
    window.addEventListener('scroll', updateRect, true);
    return () => {
      if (frameId) window.cancelAnimationFrame(frameId);
      window.removeEventListener('resize', updateRect);
      window.removeEventListener('scroll', updateRect, true);
    };
  }, [anchorRef, expanded]);

  if (typeof document === 'undefined' || !anchorRect) return null;

  const top = placement === 'top' ? anchorRect.top : anchorRect.bottom;
  const left = anchorRect.left + anchorRect.width / 2;
  const label = expanded ? expandedLabel : collapsedLabel;
  const displayLabel = label
    .replace('visualization header', 'header')
    .replace('Visualization header', 'Header');

  const emergeClass = placement === 'top'
    ? 'peridot-visualization-toggle-emerge-from-below'
    : 'peridot-visualization-toggle-emerge-from-above';
  const emergeDelay = placement === 'top' ? '1080ms' : '620ms';

  /*
   * These portal-mounted controls must sit above the map/chart stage but below
   * global dialogs. Keep this at the Visualizations workspace layer instead of
   * treating header/timeline toggles as universal top-layer UI.
   */
  return createPortal(
    <div
      className={`${emergeClass} pointer-events-auto fixed z-[400]`}
      style={{ left, top, '--peridot-toggle-emerge-delay': emergeDelay }}
    >
      <button
        type="button"
        onClick={onClick}
        className="flex h-7 min-w-[8.5rem] items-center justify-center gap-2 rounded-full border border-[var(--peridot-role-ornament-line-muted)] bg-[color-mix(in_srgb,var(--peridot-role-interface-panel-background-strong)_78%,transparent)] px-3 text-[var(--peridot-role-interface-text-on-dark)] shadow-[0_7px_16px_rgba(0,0,0,0.28)] backdrop-blur-[1px] transition duration-150 hover:scale-[1.02] hover:border-[var(--peridot-role-ornament-line)] hover:bg-[color-mix(in_srgb,var(--peridot-role-interface-panel-background-strong)_88%,transparent)] hover:text-[var(--peridot-role-ornament-sparkle)] focus:outline-none focus:ring-2 focus:ring-[var(--peridot-role-interface-text-on-dark)]"
        aria-label={label}
      >
        <span aria-hidden="true" className="h-px w-5 bg-gradient-to-r from-transparent to-[var(--peridot-role-ornament-line)] opacity-80" />
        <span className="text-[10px] font-extrabold uppercase tracking-[0.18em]">
          {displayLabel}
        </span>
        <span aria-hidden="true" className="h-px w-5 bg-gradient-to-l from-transparent to-[var(--peridot-role-ornament-line)] opacity-80" />
      </button>
    </div>,
    document.body
  );
}

function FloatingVisualizationMenu({
  anchorRect,
  isOpen,
  children,
  width = 300,
  onMouseEnter,
  onMouseLeave,
  onFocus,
}) {
  if (!isOpen || typeof document === 'undefined' || !anchorRect) return null;

  const margin = 12;
  const top = Math.max(margin, anchorRect.bottom + 10);
  const left = Math.max(
    margin,
    Math.min(window.innerWidth - width - margin, anchorRect.right - width)
  );
  const bridgeLeft = Math.max(margin, anchorRect.left);
  const bridgeWidth = Math.max(32, Math.min(anchorRect.width, window.innerWidth - bridgeLeft - margin));

  return createPortal(
    <>
      <div
        aria-hidden="true"
        className="fixed z-[9998]"
        style={{
          left: bridgeLeft,
          top: anchorRect.bottom,
          width: bridgeWidth,
          height: 14,
        }}
        onMouseEnter={onMouseEnter}
      />
      <div
        className="fixed z-[9999] rounded-2xl border border-[var(--peridot-color-hex-bfa46d)] bg-[var(--peridot-color-hex-fffaf0)] p-2 text-[var(--peridot-color-hex-203429)] shadow-[0_18px_38px_var(--peridot-color-rgba-rgba-0-0-0-0-36)]"
        style={{ left, top, width }}
        onMouseEnter={onMouseEnter}
        onMouseLeave={onMouseLeave}
        onFocus={onFocus}
      >
        {children}
      </div>
    </>,
    document.body
  );
}

function GeographicMapSettingsPanel({ controls }) {
  const [isOpen, setIsOpen] = useState(false);
  const [relationshipLinesOpen, setRelationshipLinesOpen] = useState(false);
  const [appearanceOpen, setAppearanceOpen] = useState(false);

  const safeControls = controls || {};

  const availableRoles = Array.isArray(safeControls.availableRoles) ? safeControls.availableRoles : [];
  const hasEntityGeography = Boolean(safeControls.hasEntityGeography);
  const appliedSettings = {
    selectedRoles: Array.isArray(safeControls.selectedRoles) ? safeControls.selectedRoles : [],
    includeMostFrequent: Boolean(safeControls.includeMostFrequent),
    lineAnchorRule: safeControls.lineAnchorRule || 'event-location',
    lineFallbackRule: safeControls.lineFallbackRule || 'most-frequent',
    cartoStyle: safeControls.cartoStyle || 'rastertiles/voyager',
    showPlaceLabels: safeControls.showPlaceLabels !== false,
    showEntityLabels: Boolean(safeControls.showEntityLabels),
  };
  const defaultSettings = {
    selectedRoles: Array.isArray(safeControls.defaultSelectedRoles) ? safeControls.defaultSelectedRoles : [],
    includeMostFrequent: safeControls.defaultIncludeMostFrequent !== false,
    lineAnchorRule: safeControls.defaultLineAnchorRule || 'event-location',
    lineFallbackRule: safeControls.defaultLineFallbackRule || 'most-frequent',
    cartoStyle: safeControls.defaultCartoStyle || 'rastertiles/voyager',
    showPlaceLabels: safeControls.defaultShowPlaceLabels !== false,
    showEntityLabels: Boolean(safeControls.defaultShowEntityLabels),
  };
  const appliedSignature = JSON.stringify({
    ...appliedSettings,
    selectedRoles: [...appliedSettings.selectedRoles].sort(),
  });
  const [draftSettings, setDraftSettings] = useState(appliedSettings);

  useEffect(() => {
    setDraftSettings(appliedSettings);
  // `appliedSignature` intentionally collapses parent rerenders that do not
  // change the committed map settings. Draft edits therefore survive Timeline,
  // playback, hover, and other workspace updates until Apply or Reset.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appliedSignature]);

  const selectedRoles = new Set(Array.isArray(draftSettings.selectedRoles) ? draftSettings.selectedRoles : []);
  const cartoStyle = draftSettings.cartoStyle || 'rastertiles/voyager';
  const includeMostFrequent = Boolean(draftSettings.includeMostFrequent);
  const lineAnchorRule = draftSettings.lineAnchorRule || 'event-location';
  const lineFallbackRule = draftSettings.lineFallbackRule || 'most-frequent';
  const showPlaceLabels = draftSettings.showPlaceLabels !== false;
  const showEntityLabels = Boolean(draftSettings.showEntityLabels);
  const lineRuleOptions = [
    { value: 'event-location', label: 'Where the connection event occurred' },
    { value: 'most-frequent', label: 'Most frequent place' },
    ...availableRoles.map((role) => ({ value: `role:${role}`, label: role })),
  ];
  const fallbackRuleOptions = [
    { value: 'none', label: 'Do not draw the line' },
    { value: 'most-frequent', label: 'Most frequent place' },
    ...availableRoles.map((role) => ({ value: `role:${role}`, label: role })),
  ];
  const normalizeComparableSettings = (settings) => ({
    ...settings,
    selectedRoles: [...(settings.selectedRoles || [])].sort(),
  });
  const isDirty = JSON.stringify(normalizeComparableSettings(draftSettings)) !== JSON.stringify(normalizeComparableSettings(appliedSettings));

  const updateDraft = (updates) => {
    setDraftSettings((current) => ({ ...current, ...updates }));
  };
  const toggleDraftRole = (role, enabled) => {
    setDraftSettings((current) => {
      const nextRoles = new Set(current.selectedRoles || []);
      if (enabled) nextRoles.add(role);
      else nextRoles.delete(role);
      return { ...current, selectedRoles: Array.from(nextRoles) };
    });
  };
  const resetDraft = () => setDraftSettings(defaultSettings);
  const applyDraft = () => safeControls.onApply?.({
    selectedRoles: Array.from(new Set(draftSettings.selectedRoles || [])),
    includeMostFrequent: Boolean(draftSettings.includeMostFrequent),
    lineAnchorRule: draftSettings.lineAnchorRule || 'event-location',
    lineFallbackRule: draftSettings.lineFallbackRule || 'most-frequent',
    cartoStyle: draftSettings.cartoStyle || 'rastertiles/voyager',
    showPlaceLabels: draftSettings.showPlaceLabels !== false,
    showEntityLabels: Boolean(draftSettings.showEntityLabels),
  });

  if (!controls) return null;

  return (
    <div className="pointer-events-auto absolute right-3 top-3 z-[120] flex flex-col items-end gap-1.5">
      <button
        type="button"
        onClick={() => setIsOpen((value) => !value)}
        className={[
          'inline-flex h-9 items-center gap-2 rounded-full border px-4 text-[11px] font-extrabold tracking-[0.04em] shadow-[0_9px_22px_rgba(0,0,0,0.22)] backdrop-blur-sm transition focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]',
          isOpen
            ? 'border-[var(--peridot-role-ornament-line)] bg-[var(--peridot-color-hex-102c20)] text-[var(--peridot-color-hex-fff8e8)]'
            : 'border-[var(--peridot-role-ornament-line-muted)] bg-[var(--peridot-color-hex-102c20)] text-[var(--peridot-color-hex-fff8e8)] hover:border-[var(--peridot-role-ornament-line)] hover:text-[var(--peridot-role-ornament-sparkle)]',
        ].join(' ')}
        aria-expanded={isOpen}
        aria-controls="peridot-people-map-settings-panel"
      >
        <span aria-hidden="true">⚙</span>
        <span>Map settings</span>
      </button>

      {isOpen ? (
        <div
          id="peridot-people-map-settings-panel"
          className="max-h-[min(27rem,calc(100vh-12rem))] w-[min(18rem,calc(100vw-2rem))] overflow-y-auto rounded-2xl border border-[var(--peridot-color-hex-bfa46d)] bg-[var(--peridot-color-hex-fffaf0)] p-2.5 text-[var(--peridot-color-hex-203429)] shadow-[0_16px_38px_rgba(0,0,0,0.3)]"
        >
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="[font-family:Georgia,'Palatino_Linotype','Book_Antiqua',Palatino,serif] text-[19px] font-bold leading-tight text-[var(--peridot-color-hex-172b20)]">
                Map settings
              </h3>
              <p className="mt-0.5 text-[9px] leading-[1.35] text-[var(--peridot-color-hex-6f6554)]">
                Changes are previewed here and applied together.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-f5ecd2)] text-sm font-bold text-[var(--peridot-color-hex-6f6554)] transition hover:bg-[var(--peridot-color-hex-dfe9c8)] focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]"
              aria-label="Close map settings"
            >
              ×
            </button>
          </div>

          <section className="mt-2 rounded-[14px] border border-[var(--peridot-color-hex-d5c7a8)] bg-[var(--peridot-color-hex-fbf7ea)] p-2.5">
            <h4 className="[font-family:Georgia,'Palatino_Linotype','Book_Antiqua',Palatino,serif] text-[15px] font-bold text-[var(--peridot-color-hex-172b20)]">Basemap</h4>
            <label htmlFor="peridot-geographic-basemap-style" className="mt-1 block text-[12px] text-[var(--peridot-color-hex-52675a)]">Map style</label>
            <select
              id="peridot-geographic-basemap-style"
              aria-label="Geographic basemap style"
              value={cartoStyle}
              onChange={(event) => updateDraft({ cartoStyle: event.target.value })}
              className="mt-1 w-full rounded-lg border border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-fffaf0)] px-2 py-1.5 text-[13px] text-[var(--peridot-color-hex-172b20)]"
            >
              {(safeControls.cartoStyles || []).map((style) => <option key={style.id} value={style.id}>{style.label}</option>)}
            </select>
            <p className="mt-1 text-[10px] leading-snug text-[var(--peridot-color-hex-6f6554)]">Map imagery © CARTO and © OpenStreetMap contributors.</p>
          </section>

          <section className="mt-2 rounded-[14px] border border-[var(--peridot-color-hex-d5c7a8)] bg-[var(--peridot-color-hex-fbf7ea)] p-2.5">
            <div className="flex items-center gap-2">
              <h4 className="[font-family:Georgia,'Palatino_Linotype','Book_Antiqua',Palatino,serif] text-[15px] font-bold leading-tight text-[var(--peridot-color-hex-172b20)]">
                Node labels
              </h4>
              <span
                className="flex h-4 w-4 items-center justify-center rounded-full border border-[var(--peridot-color-hex-d8c79a)] text-[9px] font-bold text-[var(--peridot-color-hex-6f6554)]"
                title="Choose which identities are printed on geographic nodes. Both may be shown together, or both may be hidden."
                aria-label="About node labels"
              >
                i
              </span>
            </div>
            <p className="mt-1 text-[10px] leading-[1.45] text-[var(--peridot-color-hex-52675a)]">
              Geographic points are shared. Choose whether labels foreground places, people / entities, both, or neither.
            </p>
            <div className="mt-2 grid gap-0.5">
              <label className="flex items-center gap-2 rounded-lg px-1 py-1 text-[13px] font-semibold text-[var(--peridot-color-hex-26382b)] hover:bg-[var(--peridot-color-hex-edf4df)]">
                <input
                  type="checkbox"
                  checked={showPlaceLabels}
                  onChange={(event) => updateDraft({ showPlaceLabels: event.target.checked })}
                  className="h-4 w-4 rounded border-[var(--peridot-color-hex-cbdab2)]"
                />
                <span>Places</span>
              </label>
              <label className="flex items-center gap-2 rounded-lg px-1 py-1 text-[13px] font-semibold text-[var(--peridot-color-hex-26382b)] hover:bg-[var(--peridot-color-hex-edf4df)]">
                <input
                  type="checkbox"
                  checked={showEntityLabels}
                  disabled={!hasEntityGeography}
                  onChange={(event) => updateDraft({ showEntityLabels: event.target.checked })}
                  className="h-4 w-4 rounded border-[var(--peridot-color-hex-cbdab2)] disabled:cursor-not-allowed disabled:opacity-50"
                />
                <span>People / entities</span>
              </label>
            </div>
          </section>

          {hasEntityGeography ? (
          <section className="mt-2 rounded-[14px] border border-[var(--peridot-color-hex-d5c7a8)] bg-[var(--peridot-color-hex-fbf7ea)] p-2.5">
            <div className="flex items-center gap-2">
              <h4 className="[font-family:Georgia,'Palatino_Linotype','Book_Antiqua',Palatino,serif] text-[15px] font-bold leading-tight text-[var(--peridot-color-hex-172b20)]">
                Geographic anchors
              </h4>
              <span
                className="flex h-4 w-4 items-center justify-center rounded-full border border-[var(--peridot-color-hex-d8c79a)] text-[9px] font-bold text-[var(--peridot-color-hex-6f6554)]"
                title="Choose which mapped place roles can position people or entities geographically."
                aria-label="About geographic anchors"
              >
                i
              </span>
            </div>
            <div className="mt-1.5 text-[9px] font-extrabold uppercase tracking-[0.15em] text-[var(--peridot-color-hex-6f6554)]">
              Locations shown
            </div>
            <p className="mt-0.5 text-[10px] leading-[1.45] text-[var(--peridot-color-hex-52675a)]">
              Choose any mapped place roles to position people or entities. All anchor rules may be turned off.
            </p>

            <div className="mt-2 grid gap-0.5">
              {availableRoles.map((role) => (
                <label key={role} className="flex items-center gap-2 rounded-lg px-1 py-1 text-[13px] font-semibold text-[var(--peridot-color-hex-26382b)] hover:bg-[var(--peridot-color-hex-edf4df)]">
                  <input
                    type="checkbox"
                    checked={selectedRoles.has(role)}
                    onChange={(event) => toggleDraftRole(role, event.target.checked)}
                    className="h-4 w-4 rounded border-[var(--peridot-color-hex-cbdab2)]"
                  />
                  <span>{role}</span>
                </label>
              ))}

              <label className="flex items-center gap-2 rounded-lg px-1 py-1 text-[13px] font-semibold text-[var(--peridot-color-hex-26382b)] hover:bg-[var(--peridot-color-hex-edf4df)]">
                <input
                  type="checkbox"
                  checked={includeMostFrequent}
                  onChange={(event) => updateDraft({ includeMostFrequent: event.target.checked })}
                  className="h-4 w-4 rounded border-[var(--peridot-color-hex-cbdab2)]"
                />
                <span>Most frequent place</span>
              </label>
            </div>

            {!availableRoles.length ? (
              <div className="mt-2 rounded-lg border border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-f3ecd9)] px-2.5 py-1.5 text-[10px] leading-[1.45] text-[var(--peridot-color-hex-6f6554)]">
                No named place roles are mapped in this dataset. Most frequent place remains available when entity locations can be resolved.
              </div>
            ) : null}
          </section>
          ) : null}

          {hasEntityGeography ? (
          <section className="mt-2 border-t border-[var(--peridot-color-hex-d8c79a)] pt-2">
            <button
              type="button"
              onClick={() => setRelationshipLinesOpen((value) => !value)}
              className="flex w-full items-center justify-between gap-3 rounded-lg px-1 py-0.5 text-left focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]"
              aria-expanded={relationshipLinesOpen}
            >
              <span className="[font-family:Georgia,'Palatino_Linotype','Book_Antiqua',Palatino,serif] text-[15px] font-bold leading-tight text-[var(--peridot-color-hex-172b20)]">
                Relationship lines
              </span>
              <span aria-hidden="true" className="text-sm text-[var(--peridot-color-hex-6f6554)]">{relationshipLinesOpen ? '⌃' : '⌄'}</span>
            </button>
            {relationshipLinesOpen ? (
              <div className="mt-1.5 rounded-[14px] border border-[var(--peridot-color-hex-d5c7a8)] bg-[var(--peridot-color-hex-fbf7ea)] p-2.5">
                <label className="block text-[9px] font-extrabold uppercase tracking-[0.15em] text-[var(--peridot-color-hex-6f6554)]">
                  Draw relationship lines from
                  <select
                    value={lineAnchorRule}
                    onChange={(event) => updateDraft({ lineAnchorRule: event.target.value })}
                    className="mt-1 w-full rounded-lg border border-[var(--peridot-color-hex-d5c7a8)] bg-[var(--peridot-color-hex-fffaf0)] px-2 py-1.5 text-[11px] font-semibold normal-case tracking-normal text-[var(--peridot-color-hex-26382b)] focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]"
                  >
                    {lineRuleOptions.map((option) => (
                      <option key={option.value} value={option.value}>{option.label}</option>
                    ))}
                  </select>
                </label>

                {lineAnchorRule === 'event-location' ? (
                  <label className="mt-2 block text-[9px] font-extrabold uppercase tracking-[0.15em] text-[var(--peridot-color-hex-6f6554)]">
                    If unavailable
                    <select
                      value={lineFallbackRule}
                      onChange={(event) => updateDraft({ lineFallbackRule: event.target.value })}
                      className="mt-1 w-full rounded-lg border border-[var(--peridot-color-hex-d5c7a8)] bg-[var(--peridot-color-hex-fffaf0)] px-2 py-1.5 text-[11px] font-semibold normal-case tracking-normal text-[var(--peridot-color-hex-26382b)] focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]"
                    >
                      {fallbackRuleOptions.map((option) => (
                        <option key={option.value} value={option.value}>{option.label}</option>
                      ))}
                    </select>
                  </label>
                ) : null}

                <p className="mt-2 text-[10px] leading-[1.4] text-[var(--peridot-color-hex-6f6554)]">
                  Event geography is used only when a relationship record gives one explicit location for each endpoint. Peridot never multiplies one relationship across every visible anchor combination.
                </p>
              </div>
            ) : null}
          </section>
          ) : null}

          <section className="mt-2 border-t border-[var(--peridot-color-hex-d8c79a)] pt-2">
            <button
              type="button"
              onClick={() => setAppearanceOpen((value) => !value)}
              className="flex w-full items-center justify-between gap-3 rounded-lg px-1 py-0.5 text-left focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]"
              aria-expanded={appearanceOpen}
            >
              <span className="[font-family:Georgia,'Palatino_Linotype','Book_Antiqua',Palatino,serif] text-[15px] font-bold leading-tight text-[var(--peridot-color-hex-172b20)]">
                Appearance <em className="font-normal text-[var(--peridot-color-hex-6f6554)]">(Coming soon)</em>
              </span>
              <span aria-hidden="true" className="text-sm text-[var(--peridot-color-hex-6f6554)]">{appearanceOpen ? '⌃' : '⌄'}</span>
            </button>
            <p className="px-1 text-[10px] text-[var(--peridot-color-hex-6f6554)]">
              Node size, cluster size, edge width…
            </p>
            {appearanceOpen ? (
              <div className="mt-1.5 rounded-lg border border-dashed border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-fbf7ea)] px-2.5 py-1.5 text-[10px] leading-[1.45] text-[var(--peridot-color-hex-6f6554)]">
                Appearance controls will be added in the later sizing and clustering pass.
              </div>
            ) : null}
          </section>

          <div className="sticky bottom-0 mt-2 flex items-center justify-between gap-2 border-t border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-fffaf0)] pt-2">
            <button
              type="button"
              onClick={resetDraft}
              className="rounded-full border border-[var(--peridot-color-hex-bfa46d)] bg-[var(--peridot-color-hex-f5ecd2)] px-3 py-1.5 text-[9px] font-extrabold uppercase tracking-[0.12em] text-[var(--peridot-color-hex-6f6554)] transition hover:bg-[var(--peridot-color-hex-dfe9c8)] focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]"
            >
              Reset
            </button>
            <button
              type="button"
              onClick={applyDraft}
              disabled={!isDirty}
              className="rounded-full border border-[var(--peridot-color-hex-b58b42)] bg-[var(--peridot-color-hex-173120)] px-4 py-1.5 text-[9px] font-extrabold uppercase tracking-[0.12em] text-[var(--peridot-color-hex-fff8e8)] transition hover:bg-[var(--peridot-color-hex-254934)] focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)] disabled:cursor-not-allowed disabled:opacity-40"
            >
              Apply
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function CompatibilityStatusPill({ available, light = false }) {
  return (
    <span
      className={[
        'shrink-0 rounded-full border px-2 py-1 text-[10px] font-bold uppercase tracking-[0.16em]',
        light
          ? available
            ? 'border-[var(--peridot-color-hex-5f7f4f)] bg-[var(--peridot-color-hex-dfe9c8)] text-[var(--peridot-color-hex-173120)]'
            : 'border-[var(--peridot-color-hex-9b6f2f)] bg-[var(--peridot-color-hex-f0d9a8)] text-[var(--peridot-color-hex-4c3216)]'
          : available
            ? 'border-[var(--peridot-color-hex-dfe9c8-a80)] bg-[var(--peridot-color-hex-dfe9c8-a30)] text-[var(--peridot-color-hex-fff8e8)]'
            : 'border-[var(--peridot-color-hex-e7c27d)] bg-[var(--peridot-color-hex-b58b42-a35)] text-[var(--peridot-color-hex-fff2cf)]',
      ].join(' ')}
    >
      {available ? 'Available' : 'Limited'}
    </span>
  );
}

function UnavailableVisualizationState({
  title,
  why,
  availableInstead = [],
  counts = [],
}) {
  return (
    <div className="flex min-h-0 flex-1 items-center justify-center overflow-auto rounded-[28px] border border-[var(--peridot-color-hex-c4e0ef-a50)] bg-[var(--peridot-color-hex-071f16)] p-5 shadow-[0_20px_54px_var(--peridot-color-rgba-rgba-0-0-0-0-34)]">
      <div className="w-full max-w-4xl rounded-[28px] border border-[var(--peridot-color-hex-dfe9c8-a50)] bg-[var(--peridot-color-hex-f8f4e6)] p-6 text-[var(--peridot-color-hex-24382d)] shadow-[0_18px_46px_var(--peridot-color-rgba-rgba-0-0-0-0-22)]">
        <p className="peridot-kicker text-[11px] text-[var(--peridot-color-hex-66815b)]">Tool availability</p>
        <h2 className="[font-family:Georgia,'Palatino_Linotype','Book_Antiqua',Palatino,serif] text-3xl font-bold tracking-[-0.035em] text-[var(--peridot-color-hex-132a20)]">
          {title}
        </h2>
        <div className="mt-4 rounded-2xl border border-[var(--peridot-color-hex-d5c7a8)] bg-[var(--peridot-color-hex-f3ecd9)] p-4">
          <h3 className="text-sm font-bold text-[var(--peridot-color-hex-25382d)]">What is missing</h3>
          <p className="mt-2 text-sm leading-relaxed text-[var(--peridot-color-hex-4b5c50)]">{why}</p>
        </div>
        {availableInstead.length ? (
          <div className="mt-4 rounded-2xl border border-[var(--peridot-color-hex-cbdab2)] bg-[var(--peridot-color-hex-edf4df)] p-4">
            <h3 className="text-sm font-bold text-[var(--peridot-color-hex-25382d)]">Still available</h3>
            <div className="mt-3 flex flex-wrap gap-2">
              {availableInstead.map((item) => (
                <span key={item} className="rounded-full border border-[var(--peridot-color-hex-8aa36d-a50)] bg-[var(--peridot-color-hex-dfe9c8)] px-3 py-1 text-sm font-semibold text-[var(--peridot-color-hex-26382b)]">
                  {item}
                </span>
              ))}
            </div>
          </div>
        ) : null}
        {counts.length ? (
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {counts.map((item) => (
              <div key={item.label} className="rounded-2xl border border-[var(--peridot-color-hex-d5c7a8)] bg-[var(--peridot-color-hex-fffdf6)] p-3">
                <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-[var(--peridot-color-hex-6a7b65)]">{item.label}</div>
                <div className="mt-1 text-xl font-bold text-[var(--peridot-color-hex-172b20)]">{item.value}</div>
              </div>
            ))}
          </div>
        ) : null}
      </div>
    </div>
  );
}

function CapabilitySummaryWorkspace({ availability, onOpenSearch }) {
  const rows = [
    {
      label: 'Point map',
      value: availability.hasPointMap ? `${numberLabel(availability.pointCount)} mapped places` : 'Not available',
      ready: availability.hasPointMap,
      note: availability.hasPointMap
        ? 'One-location records have mapped point-place or point-coordinate roles and can be explored through the map.'
        : 'No point-place or point-coordinate roles are available in the current scope.',
    },
    {
      label: 'Route map',
      value: availability.hasRouteMap ? `${numberLabel(availability.routeCount)} routes` : 'Not available',
      ready: availability.hasRouteMap,
      note: availability.hasRouteMap
        ? 'Source-target place records have route/place roles and can be explored as routes.'
        : 'No mapped source-target place or coordinate-pair routes are available in the current scope.',
    },
    {
      label: 'Network views',
      value: availability.hasNetwork ? `${numberLabel(availability.networkEdgeCount)} relationships` : 'Not available',
      ready: availability.hasNetwork,
      note: availability.hasNetwork
        ? 'Explicitly mapped entity relationships are available and can be explored as networks.'
        : 'No explicitly mapped entity relationships are available in the current scope.',
    },
    {
      label: 'Charts',
      value: availability.hasCharts ? `${numberLabel(availability.rowCount)} records` : 'Not available',
      ready: availability.hasCharts,
      note: availability.hasCharts
        ? 'The active records can be sent to Chart Visualizations where usable categorical, numeric, date, or evidence fields are available.'
        : 'No active records or chartable fields are available for charting in the current scope.',
    },
  ];

  return (
    <div className="min-h-0 flex-1 overflow-auto rounded-[28px] border border-[var(--peridot-color-hex-c4e0ef-a50)] bg-[var(--peridot-color-hex-071f16)] p-4 shadow-[0_20px_54px_var(--peridot-color-rgba-rgba-0-0-0-0-34)]">
      <div className="rounded-[28px] border border-[var(--peridot-color-hex-dfe9c8-a50)] bg-[var(--peridot-color-hex-f8f4e6)] p-5 text-[var(--peridot-color-hex-24382d)]">
        <p className="peridot-kicker text-[11px] text-[var(--peridot-color-hex-66815b)]">Explore your data</p>
        <h2 className="[font-family:Georgia,'Palatino_Linotype','Book_Antiqua',Palatino,serif] text-3xl font-bold tracking-[-0.035em] text-[var(--peridot-color-hex-132a20)]">
          Dataset tool availability
        </h2>
        <p className="mt-2 max-w-3xl text-sm leading-relaxed text-[var(--peridot-color-hex-52675a)]">
          Peridot preserves useful records first, then reports which tools the mapped fields can support. Some datasets support maps, some support networks, some support charts, and some are best explored as searchable evidence records.
        </p>
        <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {rows.map((row) => (
            <div
              key={row.label}
              className={[
                'rounded-2xl border p-4',
                row.ready
                  ? 'border-[var(--peridot-color-hex-8aa36d-a60)] bg-[var(--peridot-color-hex-dfe9c8)]'
                  : 'border-[var(--peridot-color-hex-d5c7a8)] bg-[var(--peridot-color-hex-f3ecd9)]',
              ].join(' ')}
            >
              <div className="flex items-start justify-between gap-3">
                <h3 className="font-bold text-[var(--peridot-color-hex-172b20)]">{row.label}</h3>
                <CompatibilityStatusPill available={row.ready} />
              </div>
              <div className="mt-3 text-xl font-bold text-[var(--peridot-color-hex-172b20)]">{row.value}</div>
              <p className="mt-2 text-sm leading-relaxed text-[var(--peridot-color-hex-4e6255)]">{row.note}</p>
            </div>
          ))}
        </div>
        {onOpenSearch ? (
          <button
            type="button"
            onClick={onOpenSearch}
            className="mt-5 rounded-full border border-[var(--peridot-color-hex-8aa36d-a60)] bg-[var(--peridot-color-hex-edf4df)] px-4 py-2 text-sm font-bold text-[var(--peridot-color-hex-203429)] transition hover:border-[var(--peridot-color-hex-f5ecd2-a90)] hover:bg-[var(--peridot-color-hex-b58b42)] hover:text-[var(--peridot-color-hex-fff8e8)] focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]"
          >
            Open Search & Filter
          </button>
        ) : null}
      </div>
    </div>
  );
}

function VisualizationExportMenu({ exportControls, activeVisualizationLabel, compact = false }) {
  const peridotVisualizationTitle = `My Peridot ${activeVisualizationLabel || 'Visualization'}`;
  const upstreamDefaultTitle = exportControls?.defaultExportTitle || '';
  const defaultPngExportTitle = upstreamDefaultTitle && upstreamDefaultTitle !== 'Correspondence Visualizer'
    ? upstreamDefaultTitle
    : peridotVisualizationTitle;
  const [isOpen, setIsOpen] = useState(false);
  const [menuAnchorRect, setMenuAnchorRect] = useState(null);
  const [activeExportPanel, setActiveExportPanel] = useState('actions');
  const [pngExportTitle, setPngExportTitle] = useState(defaultPngExportTitle);
  const [includePngTitle, setIncludePngTitle] = useState(false);
  const [includePngDateRange, setIncludePngDateRange] = useState(false);
  const [includePngActiveFilters, setIncludePngActiveFilters] = useState(false);
  const [includePngResultCounts, setIncludePngResultCounts] = useState(false);
  const menuAnchorRef = useRef(null);
  const closeTimerRef = useRef(null);
  const lastAutoPngExportTitleRef = useRef(defaultPngExportTitle);

  useEffect(() => {
    /*
     * Keep the PNG title behaving like a live default rather than a stale
     * one-time initialization. If the field still contains the previous
     * generated title, update it when the active visualization changes; if a
     * user has typed a custom title, preserve their edit.
     */
    setPngExportTitle((currentTitle) => {
      const trimmedCurrentTitle = String(currentTitle || '').trim();
      const previousAutoTitle = lastAutoPngExportTitleRef.current;
      const shouldUseFreshDefault = !trimmedCurrentTitle
        || trimmedCurrentTitle === previousAutoTitle
        || trimmedCurrentTitle === 'Correspondence Visualizer';

      lastAutoPngExportTitleRef.current = defaultPngExportTitle;

      return shouldUseFreshDefault ? defaultPngExportTitle : currentTitle;
    });
  }, [defaultPngExportTitle]);

  useEffect(() => () => {
    if (closeTimerRef.current) {
      window.clearTimeout(closeTimerRef.current);
    }
  }, []);

  if (!exportControls) return null;

  const {
    exportStatus,
    handleExportSvg,
    handleExportPng,
    handleExportNodesCsv,
    handleExportEdgesCsv,
    handleExportChartPng,
    graph,
    chartRowCount,
  } = exportControls;

  const nodeCount = Number.isFinite(graph?.nodes?.length) ? graph.nodes.length : 0;
  const edgeCount = Number.isFinite(graph?.edges?.length) ? graph.edges.length : 0;
  const chartCount = Number.isFinite(chartRowCount) ? chartRowCount : null;
  const canExportSvg = typeof handleExportSvg === 'function';
  const canExportPng = typeof handleExportPng === 'function';
  const canExportNodes = typeof handleExportNodesCsv === 'function' && nodeCount > 0;
  const canExportEdges = typeof handleExportEdgesCsv === 'function' && edgeCount > 0;
  const canExportChartPng = typeof handleExportChartPng === 'function';
  const isChartExportMenu = canExportChartPng && !canExportSvg && !canExportPng && !handleExportNodesCsv && !handleExportEdgesCsv;
  const isPngOptionsPanel = activeExportPanel === 'png-options' && canExportPng;

  const clearCloseTimer = () => {
    if (closeTimerRef.current) {
      window.clearTimeout(closeTimerRef.current);
      closeTimerRef.current = null;
    }
  };

  const openMenu = () => {
    clearCloseTimer();
    if (menuAnchorRef.current) {
      setMenuAnchorRect(menuAnchorRef.current.getBoundingClientRect());
    }
    setIsOpen(true);
  };

  const closeMenu = () => {
    clearCloseTimer();
    setIsOpen(false);
    setMenuAnchorRect(null);
    setActiveExportPanel('actions');
  };

  const scheduleClose = () => {
    clearCloseTimer();
    closeTimerRef.current = window.setTimeout(() => {
      setIsOpen(false);
      setMenuAnchorRect(null);
      setActiveExportPanel('actions');
      closeTimerRef.current = null;
    }, 260);
  };

  const buttonClass = compact
    ? [
      'inline-flex h-8 min-w-[104px] items-center justify-center rounded-full border px-3 text-center text-[10px] font-extrabold uppercase tracking-[0.14em] transition duration-150 focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]',
      isOpen
        ? 'border-[var(--peridot-role-ornament-line)] bg-[var(--peridot-color-hex-b58b42-a55)] text-[var(--peridot-color-hex-fff8e8)] shadow-[inset_0_1px_0_var(--peridot-color-hex-fff8e8-a24),0_8px_18px_var(--peridot-color-rgba-rgba-0-0-0-0-20)]'
        : 'border-[var(--peridot-color-hex-dfe9c8-a36)] bg-[var(--peridot-color-hex-dfe9c8-a08)] text-[var(--peridot-color-hex-f5ecd2)] shadow-[inset_0_1px_0_var(--peridot-color-hex-fff8e8-a10)] hover:border-[var(--peridot-role-ornament-line)] hover:bg-[var(--peridot-color-hex-b58b42-a30)] hover:text-[var(--peridot-color-hex-fff8e8)] hover:shadow-[inset_0_1px_0_var(--peridot-color-hex-fff8e8-a20),0_8px_18px_var(--peridot-color-rgba-rgba-0-0-0-0-18)]',
    ].join(' ')
    : [
      'w-full rounded-2xl border px-3 py-2 text-left text-[var(--peridot-color-hex-fbf7ea)] transition focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]',
      isOpen
        ? 'border-[var(--peridot-color-hex-f5ecd2-a90)] bg-[var(--peridot-color-hex-b58b42-a75)] shadow-[0_12px_28px_var(--peridot-color-rgba-rgba-0-0-0-0-26)]'
        : 'border-[var(--peridot-color-hex-dfe9c8-a40)] bg-[var(--peridot-color-hex-dfe9c8-a10)] hover:border-[var(--peridot-color-hex-f5ecd2-a80)] hover:bg-[var(--peridot-color-hex-b58b42-a70)]',
    ].join(' ');

  const actionButtonClass = (enabled = true) => [
    'flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2 text-left text-sm transition focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]',
    enabled
      ? 'text-[var(--peridot-color-hex-1d3326)] hover:bg-[var(--peridot-color-hex-dfe9c8)]'
      : 'cursor-not-allowed text-[var(--peridot-color-hex-6f6554)] hover:bg-[var(--peridot-color-hex-f3e4bf)]',
  ].join(' ');

  const primaryActionButtonClass = (enabled = true) => [
    'mt-3 flex w-full items-center justify-center rounded-xl border px-3 py-2 text-sm font-extrabold uppercase tracking-[0.12em] transition focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]',
    enabled
      ? 'border-[var(--peridot-role-ornament-line)] bg-[var(--peridot-color-hex-b58b42)] text-[var(--peridot-color-hex-fff8e8)] hover:bg-[var(--peridot-color-hex-9b6f2f)]'
      : 'cursor-not-allowed border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-f3e4bf)] text-[var(--peridot-color-hex-6f6554)]',
  ].join(' ');

  const buildPngExportOptions = () => ({
    title: pngExportTitle,
    includeTitle: includePngTitle,
    includeDateRange: includePngDateRange,
    includeActiveFilters: includePngActiveFilters,
    includeResultCounts: includePngResultCounts,
  });

  const runAction = (handler) => {
    closeMenu();
    if (typeof handler === 'function') {
      handler();
    }
  };

  const openPngOptions = () => {
    clearCloseTimer();
    setActiveExportPanel('png-options');
  };

  return (
    <div
      ref={menuAnchorRef}
      className={compact ? 'relative z-[950]' : 'relative z-[900] min-w-[160px]'}
      onMouseEnter={openMenu}
      onMouseLeave={scheduleClose}
      onFocus={openMenu}
    >
      <button
        type="button"
        onClick={() => (isOpen ? closeMenu() : openMenu())}
        className={`${buttonClass} ${compact ? 'peridot-visualize-export' : ''}`}
        aria-expanded={isOpen}
        aria-label={`Export ${activeVisualizationLabel}`}
      >
        {compact ? (
          'Export'
        ) : (
          <>
            <span className="block text-sm font-bold">Export</span>
            <span className="mt-1 block text-[11px] leading-snug text-[var(--peridot-color-hex-dfe9c8)]">
              {isChartExportMenu ? 'PNG export' : 'SVG, PNG, and CSV'}
            </span>
          </>
        )}
      </button>

      {isOpen ? (
        <FloatingVisualizationMenu
          anchorRect={menuAnchorRect}
          isOpen={isOpen}
          width={360}
          onMouseEnter={openMenu}
          onMouseLeave={scheduleClose}
          onFocus={openMenu}
        >
          {isPngOptionsPanel ? (
            <div>
              <div className="flex items-center justify-between gap-3 px-3 pb-2 pt-1">
                <div className="text-xs font-bold uppercase tracking-[0.16em] text-[var(--peridot-color-hex-6f6554)]">
                  PNG export options
                </div>
                <button
                  type="button"
                  onClick={() => setActiveExportPanel('actions')}
                  className="rounded-full border border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-f5ecd2)] px-2 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-[var(--peridot-color-hex-6f6554)] transition hover:bg-[var(--peridot-color-hex-dfe9c8)] focus:outline-none focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a60)]"
                >
                  Back
                </button>
              </div>

              <div className="mx-1 rounded-2xl border border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-fbf7ea)] p-3 text-[var(--peridot-color-hex-26382b)]">
                <label className="block text-xs font-bold text-[var(--peridot-color-hex-1d3326)]">
                  Optional title
                  <input
                    type="text"
                    value={pngExportTitle}
                    onChange={(event) => setPngExportTitle(event.target.value)}
                    className="mt-1 w-full rounded-xl border border-[var(--peridot-color-hex-cbdab2)] bg-[var(--peridot-color-hex-f8f5e8)] px-3 py-2 text-sm font-semibold text-[var(--peridot-color-hex-1d3326)] outline-none focus:border-[var(--peridot-role-ornament-line)] focus:ring-2 focus:ring-[var(--peridot-color-hex-d6a36a-a35)]"
                    placeholder={defaultPngExportTitle || 'Map title'}
                  />
                </label>
                <div className="mt-3 grid gap-2 text-xs font-semibold text-[var(--peridot-color-hex-26382b)]">
                  {[
                    ['include-title', 'Show title at top', includePngTitle, setIncludePngTitle],
                    ['include-date-range', 'Show visible date range at bottom', includePngDateRange, setIncludePngDateRange],
                    ['include-active-filters', 'Show active filters at bottom', includePngActiveFilters, setIncludePngActiveFilters],
                    ['include-result-counts', 'Show result counts at bottom', includePngResultCounts, setIncludePngResultCounts],
                  ].map(([id, label, checked, setChecked]) => (
                    <label key={id} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={(event) => setChecked(event.target.checked)}
                        className="h-4 w-4 rounded border-[var(--peridot-color-hex-cbdab2)]"
                      />
                      <span>{label}</span>
                    </label>
                  ))}
                </div>
                <div className="mt-2 text-[11px] leading-relaxed text-[var(--peridot-color-hex-6f6554)]">
                  With all options unchecked, the PNG export contains only the visualization.
                </div>
                <button
                  type="button"
                  onClick={() => runAction(() => handleExportPng(buildPngExportOptions()))}
                  className={primaryActionButtonClass(canExportPng)}
                  disabled={!canExportPng}
                >
                  Download PNG
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="px-3 pb-2 pt-1 text-xs font-bold uppercase tracking-[0.16em] text-[var(--peridot-color-hex-6f6554)]">
                Export {activeVisualizationLabel}
              </div>

              <div className="grid gap-1">
                {canExportChartPng ? (
                  <button
                    type="button"
                    onClick={() => runAction(handleExportChartPng)}
                    className={actionButtonClass(canExportChartPng)}
                    disabled={!canExportChartPng}
                  >
                    <span>Export chart PNG</span>
                    {chartCount !== null ? (
                      <span className="shrink-0 rounded-full border border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-f5ecd2)] px-2 py-0.5 text-[10px] font-bold text-[var(--peridot-color-hex-6f6554)]">
                        {chartCount}
                      </span>
                    ) : null}
                  </button>
                ) : null}

                {canExportSvg ? (
                  <button
                    type="button"
                    onClick={() => runAction(handleExportSvg)}
                    className={actionButtonClass(canExportSvg)}
                    disabled={!canExportSvg}
                  >
                    <span>Export visualization SVG</span>
                  </button>
                ) : null}
                {canExportPng ? (
                  <button
                    type="button"
                    onClick={openPngOptions}
                    className={actionButtonClass(canExportPng)}
                    disabled={!canExportPng}
                  >
                    <span>Export visualization PNG</span>
                  </button>
                ) : null}
                {typeof handleExportNodesCsv === 'function' ? (
                  <button
                    type="button"
                    onClick={() => runAction(handleExportNodesCsv)}
                    className={actionButtonClass(canExportNodes)}
                    disabled={!canExportNodes}
                  >
                    <span>Export nodes CSV</span>
                    <span className="shrink-0 rounded-full border border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-f5ecd2)] px-2 py-0.5 text-[10px] font-bold text-[var(--peridot-color-hex-6f6554)]">
                      {nodeCount}
                    </span>
                  </button>
                ) : null}
                {typeof handleExportEdgesCsv === 'function' ? (
                  <button
                    type="button"
                    onClick={() => runAction(handleExportEdgesCsv)}
                    className={actionButtonClass(canExportEdges)}
                    disabled={!canExportEdges}
                  >
                    <span>Export routes / edges CSV</span>
                    <span className="shrink-0 rounded-full border border-[var(--peridot-color-hex-d8c79a)] bg-[var(--peridot-color-hex-f5ecd2)] px-2 py-0.5 text-[10px] font-bold text-[var(--peridot-color-hex-6f6554)]">
                      {edgeCount}
                    </span>
                  </button>
                ) : null}
              </div>
            </>
          )}

          {exportStatus?.message ? (
            <div
              className={[
                'mx-1 mt-3 rounded-xl border p-3 text-xs leading-relaxed',
                exportStatus.kind === 'error'
                  ? 'border-[var(--peridot-role-status-danger-border)] bg-[var(--peridot-role-status-danger-text)] text-[var(--peridot-role-status-danger-bg)]'
                  : 'border-[var(--peridot-color-hex-cbdab2)] bg-[var(--peridot-color-hex-edf4df)] text-[var(--peridot-color-hex-26382b)]',
              ].join(' ')}
            >
              {exportStatus.message}
              {exportStatus.filename ? (
                <div className="mt-1 font-semibold">{exportStatus.filename}</div>
              ) : null}
            </div>
          ) : null}
        </FloatingVisualizationMenu>
      ) : null}
    </div>
  );
}

export function PeridotVisualizationsWorkspace({
  mapStageProps,
  MapStageComponent,
  viewMode,
  personLayoutMode,
  visualizationsWorkspacePanel,
  analyticsWorkspaceProps,
  visualizationAvailability,
  geographicAnchorControls,
  onSelectGeographicMap,
  onSelectForceDirected,
  onSelectTimeline,
  timelineWorkspaceProps,
  onOpenAnalytics,
  onOpenChartVisualization,
  onOpenSearch,
  timelineControlsProps,
  exportControls,
}) {
  const availability = {
    rowCount: 0,
    pointCount: 0,
    routeCount: 0,
    networkNodeCount: 0,
    networkEdgeCount: 0,
    geographicNetworkNodeCount: 0,
    geographicNetworkEdgeCount: 0,
    chartFieldCount: 0,
    timelineEventCount: 0,
    hasPointMap: false,
    hasRouteMap: false,
    hasNetwork: false,
    hasForceNetwork: false,
    hasEntityNetwork: false,
    hasCharts: false,
    hasTimeline: false,
    hasExploreData: false,
    ...(visualizationAvailability || {}),
  };

  const initialTool = visualizationsWorkspacePanel === 'analytics'
    ? VISUALIZATION_TOOLS.CHART_WORKSPACE
    : visualizationsWorkspacePanel === 'timeline'
      ? VISUALIZATION_TOOLS.TIMELINE_II
      : personLayoutMode === 'force' && viewMode === 'person'
      ? VISUALIZATION_TOOLS.FORCE_NETWORK
      : VISUALIZATION_TOOLS.GEOGRAPHIC_MAP;

  const [selectedTool, setSelectedTool] = useState(initialTool);
  const [chartExportControls, setChartExportControls] = useState(null);
  const [isStageSwitching, setIsStageSwitching] = useState(false);
  const stageSwitchTimerRef = useRef(null);
  const stageRevealFrameRef = useRef(null);

  useEffect(() => {
    if (visualizationsWorkspacePanel === 'analytics') {
      setSelectedTool(VISUALIZATION_TOOLS.CHART_WORKSPACE);
    } else if (visualizationsWorkspacePanel === 'timeline') {
      setSelectedTool(VISUALIZATION_TOOLS.TIMELINE_II);
    } else if (visualizationsWorkspacePanel === 'force-directed') {
      setSelectedTool(VISUALIZATION_TOOLS.FORCE_NETWORK);
    } else if (visualizationsWorkspacePanel === 'geographic-map') {
      setSelectedTool(VISUALIZATION_TOOLS.GEOGRAPHIC_MAP);
    }
  }, [visualizationsWorkspacePanel]);

  useEffect(() => () => {
    if (stageSwitchTimerRef.current) {
      window.clearTimeout(stageSwitchTimerRef.current);
    }
    if (stageRevealFrameRef.current) {
      window.cancelAnimationFrame(stageRevealFrameRef.current);
      stageRevealFrameRef.current = null;
    }
  }, []);

  const toolDefinitions = useMemo(() => ({
    [VISUALIZATION_TOOLS.GEOGRAPHIC_MAP]: {
      label: 'Geographic Map',
      available: availability.hasPointMap || availability.hasRouteMap || availability.hasEntityNetwork,
      action: onSelectGeographicMap,
      unavailableTitle: 'Geographic Map is not available for this dataset.',
      why: 'No usable mapped geographic coordinates are available in the current scope.',
      availableInstead: [
        availability.hasForceNetwork ? 'Force-Directed Network' : null,
        availability.hasCharts ? 'Chart Visualizations' : null,
        availability.hasExploreData ? 'Explore Your Data' : null,
      ].filter(Boolean),
    },
    [VISUALIZATION_TOOLS.FORCE_NETWORK]: {
      label: 'Force-Directed Network',
      available: availability.hasForceNetwork,
      action: onSelectForceDirected,
      unavailableTitle: 'Force-Directed Network is not available for this dataset.',
      why: 'Force-directed layouts require explicitly mapped entity relationships. This dataset can still be valid for location maps, charts, search, Inspector, and export even when it does not contain network data.',
      availableInstead: [
        availability.hasPointMap || availability.hasRouteMap || availability.hasEntityNetwork ? 'Geographic Map' : null,
        availability.hasCharts ? 'Chart Visualizations' : null,
        availability.hasExploreData ? 'Explore Your Data' : null,
      ].filter(Boolean),
    },
    [VISUALIZATION_TOOLS.TIMELINE_II]: {
      label: 'Timeline',
      available: availability.hasTimeline,
      // The existing App timeline context supplies the same filtered event set.
      action: onSelectTimeline,
      unavailableTitle: 'Timeline is not available for this dataset.',
      why: 'No usable mapped temporal assertions are available in the current scope.',
      availableInstead: [availability.hasCharts ? 'Chart Visualizations' : null, availability.hasExploreData ? 'Explore Your Data' : null].filter(Boolean),
    },
    [VISUALIZATION_TOOLS.CHART_WORKSPACE]: {
      label: 'Chart Visualizations',
      available: availability.hasCharts,
      action: onOpenAnalytics,
      unavailableTitle: 'Chart Visualizations are not available for this dataset.',
      why: 'No active records or chartable fields are available for charting in the current scope.',
      availableInstead: [
        availability.hasPointMap || availability.hasRouteMap || availability.hasEntityNetwork ? 'Geographic Map' : null,
        availability.hasExploreData ? 'Explore Your Data' : null,
      ].filter(Boolean),
    },
  }), [
    availability.hasCharts,
    availability.hasEntityNetwork,
    availability.hasExploreData,
    availability.hasForceNetwork,
    availability.hasPointMap,
    availability.hasRouteMap,
    availability.hasTimeline,
    onOpenAnalytics,
    onSelectForceDirected,
    onSelectGeographicMap,
    onSelectTimeline,
  ]);

  const selectedDefinition = toolDefinitions[selectedTool] || toolDefinitions[VISUALIZATION_TOOLS.GEOGRAPHIC_MAP];
  const activeVisualizationLabel = selectedDefinition.label;

  const categories = [
    { label: 'Map', tool: VISUALIZATION_TOOLS.GEOGRAPHIC_MAP },
    { label: 'Network', tool: VISUALIZATION_TOOLS.FORCE_NETWORK },
    { label: 'Timeline', tool: VISUALIZATION_TOOLS.TIMELINE_II },
    { label: 'Charts', tool: VISUALIZATION_TOOLS.CHART_WORKSPACE },
  ];

  const selectTool = (toolKey) => {
    const tool = toolDefinitions[toolKey];

    if (stageSwitchTimerRef.current) {
      window.clearTimeout(stageSwitchTimerRef.current);
    }
    if (stageRevealFrameRef.current) {
      window.cancelAnimationFrame(stageRevealFrameRef.current);
      stageRevealFrameRef.current = null;
    }

    if (toolKey === selectedTool) {
      if (tool?.available && typeof tool.action === 'function') {
        tool.action();
      }
      return;
    }

    /*
     * Preserve the existing short stage veil while the shared Peridot loading
     * transition handles the visible heavy switch. Do not force-remount the
     * stage: viewport memory and workspace-local state rely on the stable
     * component boundary introduced in the navigation persistence pass.
     */
    setIsStageSwitching(true);
    stageSwitchTimerRef.current = window.setTimeout(() => {
      setSelectedTool(toolKey);
      if (tool?.available && typeof tool.action === 'function') {
        tool.action();
      }
      stageRevealFrameRef.current = window.requestAnimationFrame(() => {
        stageRevealFrameRef.current = null;
        setIsStageSwitching(false);
      });
    }, 120);
  };

  const isCategorySelected = (category) => {
    if (category.tool === VISUALIZATION_TOOLS.CHART_WORKSPACE) {
      return selectedTool === VISUALIZATION_TOOLS.CHART_WORKSPACE || Boolean(chartTypeFromToolKey(selectedTool));
    }
    return selectedTool === category.tool;
  };

  const tabClass = (selected) => [
    'peridot-visualize-tab relative inline-flex h-9 items-center justify-center border-b-2 px-3 text-[11px] font-extrabold uppercase tracking-[0.14em] transition duration-150',
    'focus:outline-none focus:ring-2 focus:ring-inset focus:ring-[var(--peridot-color-hex-d6a36a-a60)]',
    selected
      ? 'border-[var(--peridot-role-ornament-line)] text-[var(--peridot-color-hex-fff8e8)]'
      : 'border-transparent text-[var(--peridot-color-hex-dfe9c8)] hover:border-[var(--peridot-color-hex-dfe9c8-a45)] hover:text-[var(--peridot-color-hex-fff8e8)]',
  ].join(' ');

  const counts = [
    { label: 'Point places', value: numberLabel(availability.pointCount) },
    { label: 'Routes', value: numberLabel(availability.routeCount) },
    { label: 'Network edges', value: numberLabel(availability.networkEdgeCount) },
    { label: 'Timeline events', value: numberLabel(availability.timelineEventCount) },
    { label: 'Rows', value: numberLabel(availability.rowCount) },
  ];

  const isChartWorkspaceActive = selectedTool === VISUALIZATION_TOOLS.CHART_WORKSPACE || Boolean(chartTypeFromToolKey(selectedTool));
  const activeExportControls = isChartWorkspaceActive ? chartExportControls : exportControls;

  const renderWorkspaceBody = () => {
    if (!selectedDefinition.available) {
      return (
        <UnavailableVisualizationState
          title={selectedDefinition.unavailableTitle}
          why={selectedDefinition.why}
          availableInstead={selectedDefinition.availableInstead}
          counts={counts}
        />
      );
    }

    if (selectedTool === VISUALIZATION_TOOLS.TIMELINE_II) {
      return <PeridotTimelineII {...(timelineWorkspaceProps || {})} />;
    }

    if (selectedTool === VISUALIZATION_TOOLS.CHART_WORKSPACE || chartTypeFromToolKey(selectedTool)) {
      return (
        <div className="peridot-analytics-workspace min-h-0 flex-1 overflow-hidden">
          <AnalyticsPanelContent
            analyticsState={analyticsWorkspaceProps.analyticsState}
            onChartExportControlsChange={setChartExportControls}
          />
        </div>
      );
    }

    return (
      <div className="peridot-map-plate peridot-visualize-map-plate relative flex min-h-0 flex-1 overflow-hidden rounded-xl border border-[var(--peridot-color-hex-c4e0ef-a35)] bg-[var(--map-water)]">
        <MapStageComponent {...mapStageProps} />
        {selectedTool === VISUALIZATION_TOOLS.GEOGRAPHIC_MAP ? (
          <GeographicMapSettingsPanel controls={geographicAnchorControls} />
        ) : null}
      </div>
    );
  };

  return (
    <section className="peridot-visualize-shell flex h-full min-h-0 flex-col overflow-hidden bg-[var(--peridot-color-hex-04160f)] text-[var(--peridot-color-hex-fbf7ea)]">
      <header className="peridot-visualize-header relative shrink-0 border-b border-[var(--peridot-color-hex-dfe9c8-a20)] px-4">
        <div className="flex min-h-10 min-w-0 items-center justify-center">
          <nav
            className="flex min-w-0 items-center justify-center gap-1"
            aria-label="Visualization modes"
          >
            {categories.map((category) => {
              const selected = isCategorySelected(category);
              return (
                <button
                  key={category.label}
                  type="button"
                  className={tabClass(selected)}
                  onClick={() => selectTool(category.tool)}
                  aria-current={selected ? 'page' : undefined}
                >
                  {category.label}
                </button>
              );
            })}
          </nav>

          {activeExportControls ? (
            <div className="absolute right-4 top-1/2 shrink-0 -translate-y-1/2">
              <VisualizationExportMenu
                exportControls={activeExportControls}
                activeVisualizationLabel={activeVisualizationLabel}
                compact
              />
            </div>
          ) : null}
        </div>
      </header>

      <div className="relative z-[20] flex min-h-0 flex-1 flex-col gap-3 px-4 pb-4 pt-3">
        <div
          className={[
            'peridot-visualization-stage-transition-shell min-h-0 flex flex-1',
            isStageSwitching ? 'peridot-visualization-stage-transition-active' : '',
          ].join(' ')}
        >
          <div className="peridot-visualization-stage-transition-content min-h-0 flex flex-1">
            {renderWorkspaceBody()}
          </div>
        </div>
        {timelineControlsProps && selectedTool !== VISUALIZATION_TOOLS.TIMELINE_II ? (
          <div className="peridot-visualization-timeline-sequence shrink-0">
            <PeridotSharedChronologyAdapter {...timelineControlsProps} />
          </div>
        ) : null}
      </div>
    </section>
  );
}
